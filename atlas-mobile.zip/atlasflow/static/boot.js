/* ATLAS FLOW · CyberNyx boot sequence. Every line printed is a real check against the running backend (/api/boot, /api/ifaces, /api/listen/caps, /api/discovery/env). */
const SND=(()=>{let ctx=null;const muted=()=>PREF.get('mute',false);
 const get=()=>{if(muted())return null;try{ctx=ctx||new(window.AudioContext||window.webkitAudioContext)();if(ctx.state=='suspended')ctx.resume().catch(()=>{});return ctx}catch(e){return null}};
 const blip=(f,d=.05,type='square',v=.035,f2)=>{const c=get();if(!c||c.state!='running')return;const t=c.currentTime,o=c.createOscillator(),g=c.createGain();o.type=type;o.frequency.setValueAtTime(f,t);if(f2)o.frequency.exponentialRampToValueAtTime(f2,t+d);g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(v,t+.004);g.gain.exponentialRampToValueAtTime(.0001,t+d);o.connect(g).connect(c.destination);o.start(t);o.stop(t+d+.02)};
 const noise=(d=.12,v=.03)=>{const c=get();if(!c||c.state!='running')return;const n=c.sampleRate*d|0,b=c.createBuffer(1,n,c.sampleRate),a=b.getChannelData(0);for(let i=0;i<n;i++)a[i]=(Math.random()*2-1)*(1-i/n);const s=c.createBufferSource(),g=c.createGain(),f=c.createBiquadFilter();f.type='bandpass';f.frequency.value=2400;g.gain.value=v;s.buffer=b;s.connect(f).connect(g).connect(c.destination);s.start()};
 return{unlock:get,blip,noise,tick:()=>blip(1500+Math.random()*500,.018,'square',.012),ok:()=>blip(990,.06,'triangle',.03),warn:()=>blip(300,.12,'sawtooth',.03),
  power:()=>blip(60,.7,'sawtooth',.04,220),glitch:()=>{noise(.16,.05);blip(180,.1,'square',.03,60)},done:()=>{blip(660,.09,'triangle',.04);setTimeout(()=>blip(990,.14,'triangle',.04),90);setTimeout(()=>blip(1480,.22,'triangle',.035),190)}}})();
window.SND=SND;

/* ---- Android: switch to landscape when technically possible (Screen Orientation API; needs fullscreen + a user gesture on most browsers) ---- */
window.Android=(()=>{const isA=()=>/Android/i.test(navigator.userAgent)||(window.S&&S.plat&&S.plat.android);let armed=false;
 async function land(user){if(!isA())return false;const so=screen.orientation;if(!so||!so.lock){if(user)toast('this browser cannot lock orientation: rotate the device manually','warn');return false}
  try{await so.lock('landscape');if(user)toast('landscape locked');return true}catch(e1){try{if(!document.fullscreenElement&&document.documentElement.requestFullscreen)await document.documentElement.requestFullscreen({navigationUI:'hide'});await so.lock('landscape');if(user)toast('landscape locked');return true}catch(e2){
   if(user)toast('landscape lock refused ('+(e2.name||'error')+'): rotate manually, or use "Add to Home screen" to run fullscreen','warn');else arm();return false}}}
 function arm(){if(armed)return;armed=true;const h=()=>{removeEventListener('pointerdown',h);removeEventListener('keydown',h);land(false).then(ok=>{if(!ok&&matchMedia('(orientation:portrait)').matches)toast('rotate the device for the best layout')})};addEventListener('pointerdown',h);addEventListener('keydown',h)}
 return{land,isA}})();

const Boot=(()=>{let active=false;const sleep=ms=>new Promise(r=>setTimeout(r,ms)),fast=()=>matchMedia('(prefers-reduced-motion:reduce)').matches||!PREF.get('fx',true);
 const J=async u=>{try{return await api(u)}catch(e){return null}};
 function startApp(){if(window.ATLAS_STARTED)return;window.ATLAS_STARTED=true;try{ATLAS_START()}catch(e){console.error(e)}}
 async function run(force){
  const mode=PREF.get('boot','session');let seen=false;try{seen=!!sessionStorage.getItem('atlas.booted')}catch(e){}
  if(!force&&(mode=='off'||(mode=='session'&&seen))){startApp();if(window.Android.isA())window.Android.land(false);return}
  if(active)return;active=true;Boot.active=true;
  const el=document.createElement('div');el.id='boot';el.innerHTML=`<div class="sweep"></div><div class="bx"><div class="lg" id="bLg"><img src="/static/logo_atlas.png" alt="ATLAS"></div><div><h1>CYBER<span>NYX</span></h1><div class="sub">ATLAS FLOW · SECURITY RESEARCH INTERFACE</div><pre id="bPre"></pre><div class="pb"><i id="bPb"></i></div><div class="ft"><span id="bSt">initializing</span><span id="bHint">click / any key: skip${PREF.get('mute',false)?'':' · M: mute'}</span></div></div></div>`;
  document.body.appendChild(el);const pre=el.querySelector('#bPre'),pb=el.querySelector('#bPb'),lg=el.querySelector('#bLg'),st=el.querySelector('#bSt');
  let skip=false,F=fast();const done=()=>{skip=true};
  const keyh=e=>{if(e.key=='m'||e.key=='M'){PREF.set('mute',!PREF.get('mute',false));el.querySelector('#bHint').textContent='click / any key: skip'+(PREF.get('mute',false)?' · sound muted':'');return}SND.unlock();done()};
  el.onclick=()=>{SND.unlock();done()};addEventListener('keydown',keyh);
  /* browsers block audio until a gesture: sound plays once the user touches the page, otherwise the boot is silent (never an error) */
  SND.unlock();SND.power();window.Android.isA()&&window.Android.land(false);
  const put=(html)=>{pre.insertAdjacentHTML('beforeend',html);pre.scrollTop=pre.scrollHeight};
  const line=async(txt,tag,cls)=>{const pad=(txt+' ').padEnd(56,'.')+' ';if(skip||F){put(`${esc(pad)}<span class="${cls}">${tag}</span>\n`);return}for(const ch of pad){put(esc(ch));if(Math.random()<.35)SND.tick();await sleep(5)}put(`<span class="${cls}">${tag}</span>\n`);cls=='wn'?SND.warn():SND.ok();await sleep(70)};
  const prog=(n,t)=>{pb.style.width=Math.round(n/t*100)+'%'};
  setTimeout(()=>lg.classList.add('on','sc'),F?0:250);if(!F)setTimeout(()=>{lg.classList.add('gl');SND.glitch();setTimeout(()=>lg.classList.remove('gl'),230)},1500);
  put('<span class="dm">CyberNyx secure boot  ::  ATLAS FLOW</span>\n');
  const info=await J('/api/boot'),ifs=await J('/api/ifaces'),caps=await J('/api/listen/caps'),env=await J('/api/discovery/env');const T=8;let n=0;
  const step=async(f)=>{if(!skip)st.textContent=f[0];await line(f[1],f[2],f[3]);prog(++n,T)};
  const P=info&&info.platform;
  const L=[
   ['platform',P?`platform: ${P.system} ${P.machine}${P.android?' · Android':''}${P.termux?' · Termux':''} · Python ${P.python}`:'platform: backend unreachable',P?'[ OK ]':'[ FAIL ]',P?'ok':'wn'],
   ['privilege',P?`privilege: ${P.root?'root':'unprivileged user'}`:'privilege: unknown',P?(P.root?'[ OK ]':'[ LIMITED ]'):'[ UNKNOWN ]',P&&P.root?'ok':'wn'],
   ['interfaces',ifs?`network interfaces: ${ifs.length} enumerated`:'network interfaces: unreadable',ifs&&ifs.length?'[ OK ]':'[ UNKNOWN ]',ifs&&ifs.length?'ok':'un'],
   ['capture',caps?`raw frame access: ${caps.raw.ok?'available':'unavailable'}`:'raw frame access: unknown',caps&&caps.raw.ok?'[ OK ]':'[ LIMITED ]',caps&&caps.raw.ok?'ok':'wn'],
   ['gateway',env?`default gateway: ${env.gateway?env.gateway.ip:'not readable'}`:'default gateway: unknown',env&&env.gateway?'[ OBSERVED ]':'[ UNKNOWN ]',env&&env.gateway?'ok':'un'],
   ['dns',env?`dns resolvers: ${env.dns.servers.length?env.dns.servers.map(d=>d.ip).join(', '):'not readable'}`:'dns resolvers: unknown',env&&env.dns.servers.length?'[ OBSERVED ]':'[ UNKNOWN ]',env&&env.dns.servers.length?'ok':'un'],
   ['scope',info?`active probing: ${info.scope_locked?'locked (no authorized scope)':'scope authorized by operator'}`:'active probing: unknown',info&&info.scope_locked?'[ LOCKED ]':'[ SCOPED ]','ok'],
   ['policy','policy: passive by design · no simulated data','[ ENFORCED ]','ok']];
  for(const l of L){await step(l);if(!skip&&!F)await sleep(40)}
  st.textContent='ready';put(`\n<span class="ok">ATLAS FLOW ${esc(info?info.version:'')} online.</span>  ${info?`bound to ${esc(info.bind.host)}:${info.bind.port}`:''}\n`);prog(T,T);
  if(!skip&&!F){await sleep(450);lg.classList.add('gl');el.querySelector('h1').classList.add('gl-h');SND.glitch();await sleep(240)}
  SND.done();startApp();el.classList.add('out');removeEventListener('keydown',keyh);
  try{sessionStorage.setItem('atlas.booted','1')}catch(e){}
  setTimeout(()=>{el.remove();active=false;Boot.active=false},F?60:650)}
 return{run,get active(){return active},set active(v){active=v}}})();
window.Boot=Boot;
Boot.run(false);
