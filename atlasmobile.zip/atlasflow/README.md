# ATLAS FLOW  ·  CyberNyx
See the flow. Understand the network. Passive network + wireless analysis and local-environment discovery.
Stdlib-only Python 3 (no pip installs). Works on desktop Linux/macOS/Windows and Android/Termux.

    python3 atlasflow.py                       # then open http://127.0.0.1:8717   (Termux: opens automatically)
    python3 atlasflow.py capture.pcapng        # load a file on start
    sudo python3 atlasflow.py --capture eth0   # live capture (Linux, root / CAP_NET_RAW)
    python3 atlasflow.py --no-open             # never auto-launch a browser

## What's new in 2.0
* **CyberNyx boot sequence**: every line is a real check (platform, privilege, interfaces, raw-capture access, gateway, DNS, scope lock). Synthesized sounds (Web Audio, no files); mute in Settings or press `M`. Skip with click/any key. Once per session by default.
* **Dark-green theme**, professional, minimal glow. Logo = your original artwork (`static/logo_original.jpg`, transparent cut-outs generated from it pixel-for-pixel).
* **DISCOVERY**: interfaces, IPs, hostnames, MAC + vendor (embedded OUI subset), gateway, DNS, neighbor cache, open services. Optional **authorized TCP-connect sweep** of a private subnet (needs typed attestation, max /24, 6000-connect budget, audit-logged).
* **Provenance on every fact**: `OBSERVED` (read from OS/packets/connect result) · `DETECTED` (inferred: OUI vendor, port->service name, subnet adjacency) · `UNKNOWN` (not determinable here).
* **Live topology graph** (INTERNET > GATEWAY > HOSTS > SERVICES): animated discovery, zoom/pan/drag, select, focus, search, filters, relationship inspector, shortest relationship path (shift-click two nodes), fullscreen, touch pinch/drag.
* **LISTEN** (explicit start/stop): interface counters, observed hosts/connections, protocols, timestamps, event counts, mDNS/SSDP names. **Metadata only; payload bytes are never stored or returned.** Sources degrade honestly when the platform forbids them (reported as `unavailable` with the reason).
* Event feed, discovery timeline, asset confidence, health (ACTIVE/IDLE/STALE/CACHED), session history, exports: full JSON, topology JSON, Graphviz DOT, CSV, markdown session report, PNG.
* Console: `discover [sweep|stop]`, `assets`, `env`, `listen start|stop|stats`.

## Keyboard
`1-9` views · `[` `]` prev/next · `S` discovery start/stop · `L` listen start/stop · `/` search · `F` fullscreen · `R` fit (`Shift+R` re-layout) · `X` focus · `P` pulses · `T` dock · `I` inspector · `E` export JSON · `M` mute · `B` replay boot · `?` help · `Esc` clear

## Android / Termux
Detected via `TERMUX_VERSION` / `PREFIX`. No new dependencies. Unprivileged Termux cannot open raw sockets and Android 10+ hides `/proc/net/arp` and `/proc/net/tcp`, so there: gateway/DNS/own interfaces still work, LAN peers come from the authorized sweep, and LISTEN falls back to mDNS/SSDP + interface counters. Missing sources are shown as UNKNOWN, never invented.
The GUI requests **landscape** (Screen Orientation API; browsers require fullscreen + a tap, so it is retried on first touch). Installing the page to the home screen applies `orientation: landscape` from the manifest. A browser cannot be forced to rotate if it refuses; Settings has a "retry landscape" button.

## Safety model (unchanged and extended)
Passive by design. Not implemented: frame injection, deauth, key cracking, credential capture, exploitation, OS fingerprinting, banner grabbing.
Only active operation: single TCP `connect()` probes, locked until you attest authorization for that exact target, private/link-local space only, audit-logged. Session history is stored in `~/.atlasflow` (override with `ATLASFLOW_HOME`) as summaries and topology snapshots, never packets.
Binds to 127.0.0.1 by default. No traffic => `[ NO TRAFFIC DETECTED ]`. Nothing is simulated.
