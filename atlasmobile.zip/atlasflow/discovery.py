#!/usr/bin/env python3
"""ATLAS FLOW discovery + listen engine. Stdlib only (Termux/Android friendly).

Honesty rules enforced by construction:
  * Every fact carries a provenance label:  OBSERVED  (read directly: OS tables, packets, connect results)
                                            DETECTED  (inferred from an observed fact: OUI vendor, port->service name, subnet adjacency)
                                            UNKNOWN   (could not be determined on this platform / with these permissions)
  * Nothing is generated. Assets exist only because an OS table, a received packet or a connect() result said so.
  * Active probing (TCP connect sweep) is only possible inside an operator-authorized scope (see atlasflow.Scope),
    private/link-local address space only, explicit start/stop, hard connection budget, fully audit-logged.
  * Listen mode is passive and metadata-only: payload bytes are never stored, buffered or returned.
"""
import os, re, sys, json, time, errno, socket, struct, threading, ipaddress, subprocess, shutil, csv, io, platform as _plat
from collections import Counter, defaultdict, deque

VERSION = '2.0.0'
OBS, DET, UNK = 'OBSERVED', 'DETECTED', 'UNKNOWN'

SERV = {21: 'FTP', 22: 'SSH', 23: 'Telnet', 25: 'SMTP', 53: 'DNS', 80: 'HTTP', 110: 'POP3', 139: 'NetBIOS-SSN', 143: 'IMAP', 443: 'HTTPS',
        445: 'SMB', 515: 'LPD', 554: 'RTSP', 631: 'IPP', 993: 'IMAPS', 1883: 'MQTT', 3306: 'MySQL', 3389: 'RDP', 5432: 'PostgreSQL',
        5900: 'VNC', 8000: 'HTTP-alt', 8080: 'HTTP-alt', 8443: 'HTTPS-alt', 9100: 'JetDirect'}
PORTS_LIVENESS = (80, 443, 22, 445, 139, 53, 8080)          # stage A: cheap "is anything answering" probe set
PORTS_FULL = tuple(sorted(SERV))                            # stage B: only for hosts that answered in stage A
MAX_CONNECTS = 6000                                          # hard budget per discovery run

# Small embedded OUI subset. Vendor is DETECTED from the prefix only; absence => UNKNOWN. Not a full IEEE registry.
OUI = {'00:50:56': 'VMware', '00:0c:29': 'VMware', '00:05:69': 'VMware', '08:00:27': 'VirtualBox', '52:54:00': 'QEMU/KVM',
       '00:15:5d': 'Microsoft Hyper-V', '00:16:3e': 'Xen', 'b8:27:eb': 'Raspberry Pi', 'dc:a6:32': 'Raspberry Pi', 'e4:5f:01': 'Raspberry Pi',
       'd8:3a:dd': 'Raspberry Pi', '28:cd:c1': 'Raspberry Pi', '2c:cf:67': 'Raspberry Pi', '3c:5a:b4': 'Google', 'f4:f5:d8': 'Google',
       '00:1a:11': 'Google', '18:b4:30': 'Nest Labs', '00:03:93': 'Apple', '00:1c:b3': 'Apple', '3c:07:54': 'Apple', 'ac:bc:32': 'Apple',
       'f0:18:98': 'Apple', '00:0d:93': 'Apple', '44:65:0d': 'Amazon', '68:37:e9': 'Amazon', 'fc:65:de': 'Amazon', '00:17:88': 'Philips Lighting',
       '00:1b:21': 'Intel', '00:13:02': 'Intel', '3c:97:0e': 'Intel', '00:e0:4c': 'Realtek', '00:00:0c': 'Cisco', '00:27:22': 'Ubiquiti',
       '24:a4:3c': 'Ubiquiti', 'f0:9f:c2': 'Ubiquiti', '74:83:c2': 'Ubiquiti', 'fc:ec:da': 'Ubiquiti', '78:8a:20': 'Ubiquiti',
       '50:c7:bf': 'TP-Link', '14:cc:20': 'TP-Link', 'ec:08:6b': 'TP-Link', '00:12:fb': 'Samsung', '00:16:32': 'Samsung', '00:09:5b': 'Netgear',
       '00:14:6c': 'Netgear', '00:05:5d': 'D-Link', '00:17:9a': 'D-Link', '1c:7e:e5': 'D-Link', '24:0a:c4': 'Espressif', '30:ae:a4': 'Espressif',
       '24:6f:28': 'Espressif', 'a4:cf:12': 'Espressif', '84:0d:8e': 'Espressif', 'cc:50:e3': 'Espressif', '3c:71:bf': 'Espressif',
       '00:e0:fc': 'Huawei', '64:09:80': 'Xiaomi', '28:6c:07': 'Xiaomi', 'f8:a4:5f': 'Xiaomi', '00:50:f2': 'Microsoft', '28:18:78': 'Microsoft',
       '7c:1e:52': 'Microsoft', '00:14:22': 'Dell', '18:03:73': 'Dell', '00:1f:29': 'HP', '3c:d9:2b': 'HP', '00:01:4a': 'Sony', '00:13:a9': 'Sony'}

# evidence weights -> confidence = 1 - prod(1 - w) over DISTINCT evidence sources (deterministic, documented in the report)
WEIGHT = {'self': 1.0, 'tcp': 0.8, 'tcp-open': 0.9, 'local-listen': 0.9, 'passive': 0.6, 'capture': 0.6, 'neighbor': 0.55, 'route': 0.5, 'rdns': 0.15, 'mdns': 0.5, 'ssdp': 0.5}


# ---------------------------------------------------------------- platform + host environment readers
def platform_info():
    e = os.environ
    termux = bool(e.get('TERMUX_VERSION')) or 'com.termux' in e.get('PREFIX', '') or 'com.termux' in e.get('HOME', '')
    android = termux or sys.platform == 'android' or bool(e.get('ANDROID_ROOT') and os.path.isdir('/system'))
    euid = os.geteuid() if hasattr(os, 'geteuid') else None
    return dict(system=_plat.system(), release=_plat.release(), machine=_plat.machine(), python=_plat.python_version(), android=android,
                termux=termux, euid=euid, root=(euid == 0), hostname=socket.gethostname())

def data_dir():
    d = os.environ.get('ATLASFLOW_HOME') or os.path.join(os.path.expanduser('~'), '.atlasflow')
    try:
        os.makedirs(os.path.join(d, 'sessions'), exist_ok=True)
        t = os.path.join(d, '.w'); open(t, 'w').close(); os.remove(t); return d
    except Exception: return None

def _run(cmd, timeout=3):
    exe = shutil.which(cmd[0])
    if not exe: return None
    try:
        r = subprocess.run([exe] + cmd[1:], capture_output=True, text=True, timeout=timeout)
        return r.stdout if r.returncode == 0 and r.stdout.strip() else None
    except Exception: return None

def _rd(path):
    try:
        with open(path) as f: return f.read()
    except Exception: return None

def norm_ip(ip):
    try: return ipaddress.ip_address(str(ip).split('%')[0]).compressed
    except ValueError: return None

def vendor_of(mac):
    """-> (value, label, note)"""
    try: first = int(mac[:2], 16)
    except Exception: return None, UNK, 'no MAC'
    if first & 2: return None, UNK, 'locally-administered (randomized/virtual) MAC; vendor not derivable'
    v = OUI.get(mac[:8].lower())
    return (v, DET, 'OUI prefix match (embedded subset)') if v else (None, UNK, 'OUI not in embedded subset')

def iface_kind(n):
    n = n.lower()
    if n == 'lo': return 'loopback'
    if re.match(r'(wlan|wl|ath|ra)\d|wifi', n): return 'wireless'
    if re.match(r'(eth|en)[a-z0-9]*\d', n): return 'ethernet'
    if re.match(r'(rmnet|ccmni|ppp|pdp|wwan|usb)', n): return 'mobile'
    if re.match(r'(tun|tap|wg|tailscale|zt|utun)', n): return 'vpn'
    if re.match(r'(docker|br-|veth|virbr|vboxnet|vmnet)', n): return 'virtual'
    return 'other'

def primary_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM); s.connect(('192.0.2.1', 9)); ip = s.getsockname()[0]; s.close()  # UDP connect: route lookup only, no packet sent
        return ip
    except OSError: return None

def read_interfaces():
    out, src = [], None
    j = _run(['ip', '-j', 'addr'])
    if j:
        try:
            for x in json.loads(j):
                ad = [dict(ip=a['local'], prefix=a.get('prefixlen'), family='inet6' if a.get('family') == 'inet6' else 'inet') for a in x.get('addr_info', []) if a.get('local')]
                out.append(dict(name=x['ifname'], state=str(x.get('operstate', 'unknown')).lower(), mac=x.get('address', ''), mtu=x.get('mtu'), addrs=ad))
            src = 'ip -j addr'
        except Exception: out = []
    if not out:
        t = _run(['ifconfig'])
        if t:
            for blk in re.split(r'\n(?=\S)', t):
                m = re.match(r'(\S+?):?\s', blk)
                if not m: continue
                ad, mac = [], re.search(r'(?:ether|HWaddr)\s+([0-9a-f:]{17})', blk, re.I)
                for a in re.finditer(r'inet (?:addr:)?(\d+\.\d+\.\d+\.\d+)(?:.*?(?:netmask|Mask:)\s*(\S+))?', blk):
                    pre = None
                    if a.group(2):
                        try: pre = ipaddress.ip_network('0.0.0.0/' + (a.group(2) if '.' in a.group(2) else str(ipaddress.ip_address(int(a.group(2), 16)))), strict=False).prefixlen
                        except Exception: pass
                    ad.append(dict(ip=a.group(1), prefix=pre, family='inet'))
                out.append(dict(name=m.group(1), state='up' if 'UP' in blk.split('\n')[0] else 'unknown', mac=mac.group(1) if mac else '', mtu=None, addrs=ad))
            src = 'ifconfig' if out else None
    if not out and os.path.isdir('/sys/class/net'):
        for n in sorted(os.listdir('/sys/class/net')):
            out.append(dict(name=n, state=(_rd(f'/sys/class/net/{n}/operstate') or 'unknown').strip(), mac=(_rd(f'/sys/class/net/{n}/address') or '').strip(), mtu=None, addrs=[]))
        src = '/sys/class/net (no addresses readable)' if out else None
    pip = primary_ip()
    if pip and not any(a['ip'] == pip for i in out for a in i['addrs']):
        out.append(dict(name='(route-selected)', state='up', mac='', mtu=None, addrs=[dict(ip=pip, prefix=None, family='inet')], assumed=True))
        src = (src + ' + ' if src else '') + 'route lookup'
    for i in out: i['kind'] = iface_kind(i['name'])
    return out, src

def read_gateway():
    t = _rd('/proc/net/route')
    if t:
        for line in t.splitlines()[1:]:
            p = line.split()
            if len(p) >= 8 and p[1] == '00000000' and int(p[3], 16) & 2:
                return dict(ip=socket.inet_ntoa(struct.pack('<I', int(p[2], 16))), iface=p[0], src='/proc/net/route')
    r = _run(['ip', 'route', 'show', 'default'])
    if r:
        m = re.search(r'default via (\S+)(?: dev (\S+))?', r)
        if m: return dict(ip=m.group(1), iface=m.group(2), src='ip route')
    return None

def read_dns():
    servers, search, src = [], [], []
    def parse(path):
        t = _rd(path)
        if t is None: return False
        for l in t.splitlines():
            p = l.split()
            if len(p) >= 2 and p[0] == 'nameserver' and norm_ip(p[1]): servers.append(norm_ip(p[1]))
            elif len(p) >= 2 and p[0] in ('search', 'domain'): search.extend(p[1:])
        src.append(path); return True
    parse('/etc/resolv.conf')
    if os.environ.get('PREFIX'): parse(os.path.join(os.environ['PREFIX'], 'etc/resolv.conf'))
    stub = [s for s in servers if s in ('127.0.0.53', '127.0.0.1', '::1')]
    if stub: parse('/run/systemd/resolve/resolv.conf')
    for n in ('net.dns1', 'net.dns2', 'net.dns3', 'net.dns4'):
        v = _run(['getprop', n])
        if v and norm_ip(v.strip()): servers.append(norm_ip(v.strip())); src.append('getprop ' + n)
    seen, out = set(), []
    for s in servers:
        if s in seen: continue
        seen.add(s); a = ipaddress.ip_address(s); out.append(dict(ip=s, local=bool(a.is_private or a.is_loopback or a.is_link_local), stub=s in stub))
    return dict(servers=out, search=sorted(set(search)), src=src)

def read_neighbors():
    """-> (rows, readable_sources). rows: ip -> dict(mac, iface, state). Reads OS neighbor cache only; sends nothing."""
    rows, ok = {}, []
    t = _rd('/proc/net/arp')
    if t is not None:
        ok.append('/proc/net/arp')
        for line in t.splitlines()[1:]:
            p = line.split()
            if len(p) >= 6 and int(p[2], 16) & 2 and p[3] != '00:00:00:00:00:00': rows[norm_ip(p[0])] = dict(mac=p[3].lower(), iface=p[5], state='CACHED')
    j = _run(['ip', '-j', 'neigh'])
    if j:
        try:
            ok.append('ip -j neigh')
            for x in json.loads(j):
                st = (x.get('state') or ['?'])[0]
                if x.get('lladdr') and st in ('REACHABLE', 'STALE', 'DELAY', 'PROBE', 'PERMANENT') and norm_ip(x.get('dst')):
                    rows[norm_ip(x['dst'])] = dict(mac=x['lladdr'].lower(), iface=x.get('dev'), state=st)
        except Exception: pass
    return rows, ok

def read_netdev():
    t = _rd('/proc/net/dev')
    if t is None: return None
    out = {}
    for line in t.splitlines()[2:]:
        if ':' not in line: continue
        n, v = line.split(':', 1); f = v.split()
        if len(f) >= 16: out[n.strip()] = dict(rx_b=int(f[0]), rx_p=int(f[1]), rx_e=int(f[2]), rx_d=int(f[3]), tx_b=int(f[8]), tx_p=int(f[9]), tx_e=int(f[10]), tx_d=int(f[11]))
    return out

def _hex_ip(h):
    try:
        if len(h) == 8: return socket.inet_ntoa(struct.pack('<I', int(h, 16)))
        return socket.inet_ntop(socket.AF_INET6, b''.join(struct.pack('<I', int(h[i:i + 8], 16)) for i in range(0, 32, 8)))
    except Exception: return None

def read_sockets():
    """Local host sockets from /proc/net/tcp{,6}: -> list of (state, lip, lport, rip, rport) or None if unreadable. No process info, no payload."""
    rows, ok = [], False
    for f in ('/proc/net/tcp', '/proc/net/tcp6'):
        t = _rd(f)
        if t is None: continue
        ok = True
        for line in t.splitlines()[1:]:
            p = line.split()
            if len(p) < 4: continue
            try:
                (la, lp), (ra, rp) = p[1].split(':'), p[2].split(':')
                rows.append((p[3], _hex_ip(la), int(lp, 16), _hex_ip(ra), int(rp, 16)))
            except Exception: pass
    return rows if ok else None

def parse_mdns(b, dname):
    """mDNS answers -> (name->ips, service types advertised). Names/records only; no TXT bodies are kept."""
    if len(b) < 12: return {}, set()
    _, f, qd, an, ns, ar = struct.unpack('>HHHHHH', b[:12]); o, names, svc = 12, {}, set()
    try:
        for _ in range(min(qd, 8)): _, o = dname(b, o); o += 4
        for _ in range(min(an + ns + ar, 64)):
            nm, o = dname(b, o)
            if o + 10 > len(b): break
            t, _, _, rl = struct.unpack('>HHIH', b[o:o + 10]); o += 10; r = b[o:o + rl]
            if t == 1 and rl == 4: names.setdefault(nm, []).append(socket.inet_ntoa(r))
            elif t == 28 and rl == 16: names.setdefault(nm, []).append(socket.inet_ntop(socket.AF_INET6, r))
            elif t == 12 and nm.startswith('_') and f >> 15: svc.add(nm)
            o += rl
    except Exception: pass
    return names, svc

def parse_ssdp(b):
    try: t = b[:1500].decode('latin1')
    except Exception: return None
    h = {}
    for l in t.split('\r\n')[1:]:
        if ':' in l:
            k, v = l.split(':', 1); h[k.strip().upper()] = v.strip()[:90]
    return dict(nt=h.get('NT') or h.get('ST'), nts=h.get('NTS'), server=h.get('SERVER')) if t.startswith(('NOTIFY', 'M-SEARCH', 'HTTP/1.1 200')) else None

def tcp_probe(ip, port, timeout):
    fam = socket.AF_INET6 if ':' in ip else socket.AF_INET; t = time.time(); sk = socket.socket(fam, socket.SOCK_STREAM); sk.settimeout(timeout)
    try: sk.connect((ip, port)); return 'open', (time.time() - t) * 1000
    except ConnectionRefusedError: return 'closed', (time.time() - t) * 1000
    except socket.timeout: return 'timeout', None
    except OSError as e: return ('unreachable' if e.errno in (errno.EHOSTUNREACH, errno.ENETUNREACH, errno.ENETDOWN) else 'error'), None
    finally: sk.close()

def timed(fn, arg, timeout):
    box = []
    def w():
        try: box.append(fn(arg))
        except Exception: pass
    t = threading.Thread(target=w, daemon=True); t.start(); t.join(timeout); return box[0] if box else None


# ---------------------------------------------------------------- engine
class Engine:
    def __init__(s, store, scope, dissect, dname, is_priv, capture_live):
        s.S, s.SC, s._dissect, s.dname, s.is_priv, s.capture_live = store, scope, dissect, dname, is_priv, capture_live
        s.lock = threading.RLock(); s.plat = platform_info(); s.home = data_dir(); s.sessions = s._load_sessions()
        s.job = None; s.listener = Listener(s); s.reset(keep_history=True)

    # ---- inventory
    def reset(s, keep_history=True):
        with s.lock:
            s.assets, s.ipidx, s.macidx, s.flows, s.xedges, s.seen_edges = {}, {}, {}, {}, {}, set()
            s.events, s.seq, s.rev, s.env, s.cap_rev, s.cap_t = deque(maxlen=3000), 0, 0, None, -1, 0
            s.ev('SESSION', 'inventory reset: all discovered assets cleared', UNK)

    def ev(s, kind, msg, lbl=None, ref=None):
        with s.lock: s.seq += 1; s.rev += 1; s.events.append(dict(seq=s.seq, t=time.time(), k=kind, msg=msg, l=lbl, ref=ref))

    def _attr(s, a, k, v, lbl, src, note=None):
        cur = a['attrs'].get(k)
        if cur and cur['v'] == v and cur['l'] == lbl: return False
        if cur and cur['l'] == OBS and lbl != OBS: return False
        a['attrs'][k] = dict(v=v, l=lbl, s=src, n=note); return True

    def observe(s, ip, source, mac=None, name=None, name_src=None, kind=None, iface=None, confirm=True, ts=None, extra=None):
        ip = norm_ip(ip)
        if not ip: return None
        ad = ipaddress.ip_address(ip); ts = ts or time.time()
        if ad.is_multicast or ad.is_unspecified or ip == '255.255.255.255' or (ad.is_loopback and source not in ('tcp', 'self')): return None
        with s.lock:
            aid = s.ipidx.get(ip) or (s.macidx.get(mac) if mac else None); a = s.assets.get(aid) if aid else None; new = a is None
            if new:
                a = s.assets[ip] = dict(id=ip, ips=[ip], kind=kind or 'host', attrs={}, ports={}, src={}, first=ts, last=ts, last_conf=None, last_cache=None, mdns=set(), roles=set(), local=bool(s.is_priv(ip) or ad.is_loopback))
                s.ipidx[ip] = ip
                s.ev('ASSET', f"{kind or 'host'} {ip} discovered via {source}", OBS, ip)
            elif ip not in a['ips']: a['ips'].append(ip); s.ipidx[ip] = a['id']; s.ev('ASSET', f"{a['id']} also reachable as {ip} (same MAC)", OBS, a['id'])
            if kind in ('self', 'gateway') and a['kind'] == 'host': a['kind'] = kind
            e = a['src'].setdefault(source, dict(n=0, first=ts)); e['n'] += 1; e['last'] = ts; a['last'] = max(a['last'], ts)
            if confirm: a['last_conf'] = ts
            else: a['last_cache'] = ts
            if mac:
                mac = mac.lower(); s.macidx[mac] = a['id']
                if s._attr(a, 'mac', mac, OBS, source): s.ev('MAC', f"{a['id']} MAC {mac}", OBS, a['id'])
                v, l, n = vendor_of(mac)
                if s._attr(a, 'vendor', v, l, 'OUI', n) and v: s.ev('MAC', f"{a['id']} vendor {v} (OUI prefix)", DET, a['id'])
            if iface: s._attr(a, 'iface', iface, OBS, source)
            if name and s._attr(a, 'hostname', name, OBS, name_src or source): s.ev('NAME', f"{a['id']} hostname {name} ({name_src or source})", OBS, a['id'])
            for k, v in (extra or {}).items(): s._attr(a, k, v, OBS, source)
            return a

    def add_port(s, ip, port, rtt=None, source='tcp-open'):
        with s.lock:
            a = s.observe(ip, 'self' if source == 'local-listen' else 'tcp', confirm=True)
            if not a: return
            a['src'].setdefault(source, dict(n=0, first=time.time()))['n'] += 1; a['src'][source]['last'] = time.time()
            p = a['ports'].get(port)
            if not p:
                p = a['ports'][port] = dict(port=port, proto='tcp', state='open', service=SERV.get(port), first=time.time(), last=time.time(), rtt=rtt, via=source)
                s.ev('PORT', f"{a['id']}:{port}/tcp open" + (f" (service guess: {SERV[port]})" if port in SERV else ''), OBS, a['id'])
            p['last'] = time.time(); p['rtt'] = rtt if rtt is not None else p['rtt']

    def flow(s, a, b, n=1, by=0, via='passive'):
        a, b = norm_ip(a), norm_ip(b)
        if not a or not b: return
        with s.lock:
            f = s.flows.setdefault((a, b), dict(a=a, b=b, n=0, by=0, first=time.time(), last=0, via=set())); f['n'] += n; f['by'] += by; f['last'] = time.time(); f['via'].add(via)

    def conf(s, a):
        p = 1.0
        for src in a['src']: p *= 1 - WEIGHT.get(src, 0.3)
        return round(1 - p, 3)

    def health(s, a, now=None):
        now = now or time.time()
        if a['kind'] == 'self': return 'SELF'
        lc = a['last_conf']
        if lc is None: return 'CACHED' if a['last_cache'] else 'UNKNOWN'
        age = now - lc
        return 'ACTIVE' if age < 60 else 'IDLE' if age < 600 else 'STALE'

    # ---- environment
    def read_env(s):
        ifs, src = read_interfaces(); gw = read_gateway(); dns = read_dns(); rows, nsrc = read_neighbors(); socks = read_sockets()
        nets = []
        for i in ifs:
            if i['kind'] == 'loopback': continue
            for a in i['addrs']:
                if a['family'] != 'inet': continue
                try:
                    ip = ipaddress.ip_address(a['ip'])
                    if not (ip.is_private or ip.is_link_local): continue
                    pre = a['prefix'] if a['prefix'] else 24
                    n = ipaddress.ip_network(f"{a['ip']}/{max(pre, 24)}", strict=False)
                    nets.append(dict(net=str(n), iface=i['name'], prefix_known=bool(a['prefix']), clamped=bool(a['prefix'] and a['prefix'] < 24), own=a['ip']))
                except ValueError: pass
        return dict(platform=s.plat, interfaces=ifs, iface_src=src, gateway=gw, dns=dns, subnets=nets, neighbor_src=nsrc, neighbor_readable=bool(nsrc),
                    sockets_readable=socks is not None, primary_ip=primary_ip(), t=time.time())

    def local_phase(s):
        env = s.env = s.read_env()
        s.ev('PHASE', f"interfaces: {len([i for i in env['interfaces'] if i['kind'] != 'loopback'])} non-loopback via {env['iface_src'] or 'no readable source'}", OBS if env['iface_src'] else UNK)
        selfa = None
        for i in env['interfaces']:
            if i['kind'] == 'loopback': continue
            for ad in i['addrs']:
                if ad['family'] == 'inet6' and ad['ip'].startswith('fe80') and selfa: continue
                a = s.observe(ad['ip'], 'self', mac=i['mac'] or None, kind='self', iface=i['name'], name=s.plat['hostname'] if not selfa else None, name_src='gethostname')
                if a and not selfa: selfa = a
                elif a and selfa and a is not selfa: pass
        if selfa:
            socks = read_sockets()
            for st, lip, lp, rip, rp in socks or []:
                if st == '0A' and lip not in ('127.0.0.1', '::1') and lip is not None: s.add_port(selfa['id'], lp, source='local-listen')
            if socks is None: s.ev('WARN', 'local sockets unreadable (platform restriction): this host\'s listening ports are UNKNOWN', UNK)
        gw = env['gateway']
        if gw:
            a = s.observe(gw['ip'], 'route', kind='gateway', iface=gw['iface'], confirm=False); s.ev('PHASE', f"default gateway {gw['ip']} on {gw['iface']} ({gw['src']})", OBS)
        else: s.ev('WARN', 'no default gateway readable: gateway is UNKNOWN', UNK)
        d = env['dns']
        s.ev('PHASE', f"DNS resolvers: {', '.join(x['ip'] for x in d['servers']) or 'none readable'}", OBS if d['servers'] else UNK)
        s.refresh_neighbors()
        if not env['neighbor_readable']: s.ev('WARN', 'OS neighbor cache unreadable here (Android/permissions): LAN peers can only be found by authorized sweep or passive listen', UNK)

    def refresh_neighbors(s):
        rows, ok = read_neighbors(); n = 0
        own = {ip for a in s.assets.values() if a['kind'] == 'self' for ip in a['ips']}
        for ip, r in rows.items():
            if ip in own or not ip: continue
            if s.observe(ip, 'neighbor', mac=r['mac'], iface=r['iface'], confirm=(r['state'] == 'REACHABLE')): n += 1
        return n

    # ---- jobs
    def default_targets(s):
        return [x['net'] for x in (s.env or s.read_env())['subnets']]

    def start(s, sweep=False, targets=None, ports=None, rdns=True):
        with s.lock:
            if s.job and s.job['state'] == 'running': raise RuntimeError('a discovery run is already active')
            sid = time.strftime('d-%Y%m%d-%H%M%S')
            opts = dict(sweep=bool(sweep), targets=targets or None, ports=[int(p) for p in ports][:64] if ports else None, rdns=bool(rdns))
            for p in opts['ports'] or []:
                if not 0 < p < 65536: raise ValueError('bad port ' + str(p))
            s.job = dict(id=sid, type='discovery', state='running', phase='local', started=time.time(), ended=None, done=0, total=0, alive=0, open=0, opts=opts, stop=threading.Event(), note='')
            threading.Thread(target=s._run, args=(s.job,), daemon=True).start()
            return sid

    def stop(s):
        with s.lock:
            if s.job and s.job['state'] == 'running': s.job['stop'].set(); s.ev('SESSION', 'stop requested', UNK)

    def _run(s, job):
        o = job['opts']
        try:
            s.ev('SESSION', f"discovery {job['id']} started ({'local + authorized sweep' if o['sweep'] else 'local observation only'})", OBS)
            s.local_phase()
            if o['sweep'] and not job['stop'].is_set(): s.sweep(job)
            elif not o['sweep']: s.ev('PHASE', 'active sweep not requested: results limited to what the OS and passive sources already know', UNK)
            if o['rdns'] and not job['stop'].is_set(): s.rdns_phase(job)
            job['state'] = 'stopped' if job['stop'].is_set() else 'done'
        except Exception as e:
            job['state'] = 'error'; job['note'] = f'{type(e).__name__}: {e}'; s.ev('WARN', 'discovery error: ' + job['note'], UNK)
        finally:
            job['ended'] = time.time(); job['phase'] = 'idle'
            s.ev('SESSION', f"discovery {job['id']} {job['state']}: {s._counts()}", OBS)
            s._save_session(job)

    def _counts(s):
        with s.lock:
            h = len(s.assets); p = sum(len(a['ports']) for a in s.assets.values()); return f"{h} assets, {p} open services"

    def sweep(s, job):
        from concurrent.futures import ThreadPoolExecutor
        o, android = job['opts'], s.plat['android']; job['phase'] = 'sweep'
        tg = o['targets'] or s.default_targets(); ips, locked = [], []
        for t in tg:
            try: net = ipaddress.ip_network(t, strict=False)
            except ValueError: s.ev('WARN', f'bad target {t}', UNK); continue
            if not (net.is_private or net.is_link_local or net.is_loopback): s.ev('WARN', f'{t} is not private/link-local address space: refused', UNK); locked.append(t); continue
            if net.num_addresses > 256: s.ev('WARN', f'{t} larger than /24: refused', UNK); locked.append(t); continue
            hs = [str(h) for h in (net.hosts() if net.num_addresses > 2 else net)]
            if not all(s.SC.allowed(h) for h in hs): s.ev('WARN', f'SWEEP LOCKED for {t}: not inside an authorized scope (Settings > Authorization)', UNK); locked.append(t); continue
            ips += hs
        own = {ip for a in s.assets.values() if a['kind'] == 'self' for ip in a['ips']}; ips = [i for i in dict.fromkeys(ips) if i not in own]
        if not ips: job['note'] = 'sweep locked or no targets' if locked else 'no sweepable targets'; s.ev('WARN', 'no authorized targets to sweep', UNK); return
        W, T = (32, 1.0) if android else (64, 0.7); budget = MAX_CONNECTS
        s.SC.log(f"discovery sweep start: {len(ips)} address(es), liveness ports {list(PORTS_LIVENESS)} (tcp connect only)")
        A = [(ip, p) for ip in ips for p in PORTS_LIVENESS][:budget]; job['total'] = len(A); alive, done = set(), 0
        s.ev('SCAN', f'stage A: liveness probe of {len(ips)} addresses x {len(PORTS_LIVENESS)} ports', OBS)
        def one(t):
            if job['stop'].is_set(): return t, ('skipped', None)
            return t, tcp_probe(t[0], t[1], T)
        with ThreadPoolExecutor(max_workers=W) as ex:
            for (ip, p), (st, rtt) in ex.map(one, A):
                done += 1; job['done'] = done
                if st in ('open', 'closed'):
                    if ip not in alive: alive.add(ip); job['alive'] = len(alive); s.observe(ip, 'tcp', confirm=True)
                    if st == 'open': s.add_port(ip, p, rtt); job['open'] += 1
        s.refresh_neighbors()   # probing populated the OS ARP/ND cache: MACs for hosts that answered nothing on our ports
        with s.lock:
            for ip in ips:
                a = s.assets.get(s.ipidx.get(ip))
                if a and ip not in alive and 'neighbor' in a['src']: alive.add(ip)
        job['alive'] = len(alive)
        if job['stop'].is_set(): s.SC.log('discovery sweep stopped by operator'); return
        ports = tuple(o['ports'] or PORTS_FULL); B = [(ip, p) for ip in sorted(alive) for p in ports][:max(0, budget - len(A))]
        job['total'] += len(B); s.ev('SCAN', f'stage B: {len(alive)} responding host(s) x {len(ports)} ports', OBS)
        with ThreadPoolExecutor(max_workers=W) as ex:
            for (ip, p), (st, rtt) in ex.map(one, B):
                done += 1; job['done'] = done
                if st == 'open': s.add_port(ip, p, rtt); job['open'] = sum(len(a['ports']) for a in s.assets.values())
        s.SC.log(f"discovery sweep end: {done} connects, {len(alive)} responding host(s)" + (' (stopped)' if job['stop'].is_set() else ''))

    def rdns_phase(s, job):
        job['phase'] = 'names'
        with s.lock: todo = [a['id'] for a in s.assets.values() if 'hostname' not in a['attrs'] and a['local'] and not a['id'].startswith('fe80')]
        for ip in todo[:96]:
            if job['stop'].is_set(): return
            r = timed(socket.gethostbyaddr, ip, 1.5)
            if r and r[0] and r[0] != ip:
                a = s.assets.get(ip)
                if a: s.observe(ip, 'rdns', name=r[0], name_src='PTR record', confirm=False)

    # ---- passive capture bridge (only LIVE capture; a loaded pcap is not the local environment)
    def sync_capture(s):
        S = s.S
        if not s.capture_live() or S.rev == s.cap_rev or time.time() - s.cap_t < 1: return
        s.cap_rev, s.cap_t = S.rev, time.time()
        with S.lock:
            hosts = [(ip, sorted(h['macs'])[:1], h['last']) for ip, h in S.hosts.items() if s.is_priv(ip)]
            fl = [(f['cli'], f['srv'], f['pk'], f['by']) for f in S.fl[-5000:]]
        for ip, m, last in hosts: s.observe(ip, 'capture', mac=m[0] if m else None, ts=last)
        with s.lock:
            for (a, b) in list(s.flows):
                if 'capture' in s.flows[(a, b)]['via']: del s.flows[(a, b)]
        agg = defaultdict(lambda: [0, 0])
        for c, v, pk, by in fl: agg[(c, v)][0] += pk; agg[(c, v)][1] += by
        for (c, v), (pk, by) in agg.items(): s.flow(c, v, pk, by, 'capture')

    # ---- derived topology
    def snapshot(s):
        s.sync_capture(); now = time.time()
        with s.lock:
            env = s.env or {}; gw = env.get('gateway'); nets = [ipaddress.ip_network(x['net']) for x in env.get('subnets', [])]
            gwa = s.assets.get(s.ipidx.get(gw['ip'])) if gw else None
            nodes, edges = {}, {}
            def edge(a, b, typ, lbl, count=1, info=None, last=None):
                k = f'{a}|{b}|{typ}'; edges[k] = dict(id=k, a=a, b=b, type=typ, l=lbl, n=count, info=info, last=last)
                if k not in s.seen_edges: s.seen_edges.add(k); s.ev('EDGE', f'relationship {typ}: {a} -> {b}', lbl, k)
            ext = defaultdict(lambda: dict(n=0, by=0, peers=Counter()))
            for a in s.assets.values():
                role = set(a['roles']); isgw = bool(gwa and a is gwa); kind = 'gateway' if isgw else a['kind']
                if isgw: role.add('gateway')
                for d in env.get('dns', {}).get('servers', []):
                    if d['ip'] in a['ips']: role.add('dns-resolver')
                n = dict(id=a['id'], kind=kind, ip=a['id'], ips=a['ips'], label=(a['attrs'].get('hostname') or {}).get('v') or a['id'], l=OBS if (set(a['src']) - {'route'}) else DET,
                         conf=s.conf(a), health=s.health(a, now), first=a['first'], last=a['last'], roles=sorted(role), src=sorted(a['src']),
                         mac=(a['attrs'].get('mac') or {}).get('v'), vendor=(a['attrs'].get('vendor') or {}).get('v'),
                         attrs=[dict(k=k, v=v['v'] if v['v'] is not None else '(unknown)', l=v['l'], s=v['s'], n=v.get('n')) for k, v in sorted(a['attrs'].items())],
                         ports=[dict(port=p['port'], service=p['service'], rtt=p['rtt'], l=OBS, svc_l=DET if p['service'] else UNK) for p in sorted(a['ports'].values(), key=lambda x: x['port'])],
                         mdns=sorted(a['mdns'])[:12])
                nodes[a['id']] = n
                for p in a['ports'].values():
                    sid = f"svc:{a['id']}:{p['port']}"
                    nodes[sid] = dict(id=sid, kind='service', ip=a['id'], port=p['port'], label=f"{p['service'] or 'tcp'}/{p['port']}", service=p['service'], l=OBS, svc_l=DET if p['service'] else UNK,
                                      conf=0.9, health='ACTIVE' if now - p['last'] < 600 else 'STALE', first=p['first'], last=p['last'], rtt=p['rtt'], src=[p['via']], attrs=[], ports=[], roles=[], parent=a['id'])
                    edge(a['id'], sid, 'service', OBS, 1, f"{p['port']}/tcp open", p['last'])
            selfa = next((a for a in s.assets.values() if a['kind'] == 'self'), None)
            if gwa:
                nodes['internet'] = dict(id='internet', kind='internet', label='INTERNET', l=DET, conf=0.5, health='UNKNOWN', ips=[], roles=[], src=['route'], attrs=[dict(k='basis', v='default route present via ' + gw['ip'], l=DET, s='route table', n=None), dict(k='reachability', v='(not tested)', l=UNK, s='-', n='ATLAS does not probe the Internet')], ports=[])
                edge('internet', gwa['id'], 'uplink', DET, 1, 'default route (reachability untested)')
                if selfa: edge(selfa['id'], gwa['id'], 'route', OBS, 1, f"default route on {gw['iface']}")
            for d in env.get('dns', {}).get('servers', []):
                if d['stub'] or not selfa: continue
                tgt = s.ipidx.get(d['ip'])
                if not tgt:
                    tgt = 'dns:' + d['ip']; nodes[tgt] = dict(id=tgt, kind='dns', ip=d['ip'], label='DNS ' + d['ip'], l=OBS, conf=0.7, health='UNKNOWN', ips=[d['ip']], roles=['dns-resolver'], src=['resolv.conf'],
                                                          attrs=[dict(k='configured resolver', v=d['ip'], l=OBS, s='resolver config', n=None)], ports=[])
                    if not d['local'] and 'internet' in nodes: edge(tgt, 'internet', 'uplink', DET, 1, 'non-local resolver address')
                edge(selfa['id'], tgt, 'resolver', OBS, 1, 'configured DNS resolver')
            for a in s.assets.values():
                if a is gwa or a['kind'] == 'self' or not gwa: continue
                onlink = 'neighbor' in a['src'] or any(ipaddress.ip_address(i) in n for i in a['ips'] if ':' not in i for n in nets)
                if onlink: edge(gwa['id'], a['id'], 'lan', DET, 1, 'same subnet / neighbor-cache adjacency (inferred)', a['last'])
            for (x, y), f in s.flows.items():
                ax, ay = s.assets.get(s.ipidx.get(x)), s.assets.get(s.ipidx.get(y))
                if ax and ay and ax is not ay: edge(ax['id'], ay['id'], 'flow', OBS, f['n'], f"{f['n']} pkts observed ({'/'.join(sorted(f['via']))})", f['last'])
                elif ax and not ay and y and not s.is_priv(y) and not ipaddress.ip_address(y).is_multicast: ext[ax['id']]['n'] += f['n']; ext[ax['id']]['by'] += f['by']; ext[ax['id']]['peers'][y] += f['n']
            for aid, e in ext.items():
                if 'internet' not in nodes: nodes['internet'] = dict(id='internet', kind='internet', label='INTERNET', l=DET, conf=0.5, health='UNKNOWN', ips=[], roles=[], src=['capture'], attrs=[], ports=[])
                edge(aid, 'internet', 'flow-ext', OBS, e['n'], f"{len(e['peers'])} external peer(s); top: " + ', '.join(f'{p}' for p, _ in e['peers'].most_common(5)))
            lc = Counter(n['l'] for n in nodes.values()); kc = Counter(n['kind'] for n in nodes.values())
            return dict(rev=s.rev, now=now, nodes=list(nodes.values()), edges=list(edges.values()), stats=dict(kinds=dict(kc), labels=dict(lc), edges=len(edges)), job=s.job_view(), listen=s.listener.brief(),
                        gateway=gw, primary_ip=env.get('primary_ip'))

    def job_view(s):
        j = s.job
        return None if not j else {k: v for k, v in j.items() if k != 'stop'}

    def events_since(s, since=0, limit=400):
        with s.lock:
            ev = [e for e in s.events if e['seq'] > since]; return dict(events=ev[-limit:], seq=s.seq)

    # ---- sessions / history
    def _load_sessions(s):
        if not s.home: return []
        try: return json.load(open(os.path.join(s.home, 'sessions.json')))
        except Exception: return []

    def _save_session(s, job, listen=None):
        rec = dict(id=job['id'], type=job['type'], started=job['started'], ended=job.get('ended') or time.time(), state=job['state'], opts=job.get('opts'), note=job.get('note', ''))
        snap = s.export('json') if job['type'] == 'discovery' else dict(listen=listen)
        rec['summary'] = dict(assets=len([n for n in snap.get('nodes', []) if n['kind'] not in ('service', 'internet', 'dns')]), services=len([n for n in snap.get('nodes', []) if n['kind'] == 'service']),
                              edges=len(snap.get('edges', []))) if job['type'] == 'discovery' else dict(events=listen.get('events', 0), hosts=listen.get('hosts', 0), conns=listen.get('conns', 0))
        with s.lock:
            s.sessions.append(rec); s.sessions = s.sessions[-60:]
            if s.home:
                try:
                    json.dump(s.sessions, open(os.path.join(s.home, 'sessions.json'), 'w'))
                    json.dump(snap, open(os.path.join(s.home, 'sessions', job['id'] + '.json'), 'w'), default=str)
                    fs = sorted(os.listdir(os.path.join(s.home, 'sessions')))
                    for f in fs[:-25]: os.remove(os.path.join(s.home, 'sessions', f))
                except Exception: pass

    def session_file(s, sid):
        if not s.home or not re.fullmatch(r'[dl]-\d{8}-\d{6}', sid): return None
        return _rd(os.path.join(s.home, 'sessions', sid + '.json'))

    def clear_history(s):
        with s.lock:
            s.sessions = []
            if s.home:
                try:
                    json.dump([], open(os.path.join(s.home, 'sessions.json'), 'w'))
                    for f in os.listdir(os.path.join(s.home, 'sessions')): os.remove(os.path.join(s.home, 'sessions', f))
                except Exception: pass

    # ---- exports
    def export(s, fmt='json'):
        snap = s.snapshot(); ts = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
        full = dict(format='atlasflow-discovery/1', generated=ts, atlasflow=VERSION, platform=s.plat, environment=s.env, nodes=snap['nodes'], edges=snap['edges'],
                    stats=snap['stats'], sessions=s.sessions[-10:], events=list(s.events)[-500:], audit=[dict(t=x['t'], msg=x['msg']) for x in s.SC.audit[-200:]],
                    method=dict(labels={OBS: 'read directly from OS tables, received packets or connect() results', DET: 'inferred from an observed fact', UNK: 'could not be determined'},
                                confidence='1 - prod(1 - w) over distinct evidence sources; w=' + json.dumps(WEIGHT), health='ACTIVE<60s, IDLE<10min, STALE otherwise since last confirming evidence; CACHED = only a neighbor-cache entry'))
        if fmt == 'json': return full
        if fmt == 'topology':
            return dict(format='atlasflow-topology/1', generated=ts, nodes=[dict(id=n['id'], kind=n['kind'], label=n['label'], provenance=n['l'], confidence=n.get('conf'), health=n.get('health')) for n in snap['nodes']],
                        links=[dict(source=e['a'], target=e['b'], type=e['type'], provenance=e['l'], weight=e['n']) for e in snap['edges']])
        if fmt == 'dot':
            L = ['digraph atlasflow {', '  rankdir=TB; bgcolor="#070b0a"; node [fontname="monospace", fontcolor="#d6e0da", color="#3fb67a"]; edge [color="#3b5a49", fontcolor="#7b8e84", fontname="monospace", fontsize=9];']
            sty = {OBS: 'solid', DET: 'dashed', UNK: 'dotted'}; shp = dict(internet='doubleoctagon', gateway='diamond', self='box', host='ellipse', service='component', dns='triangle')
            for n in snap['nodes']: L.append(f'  "{n["id"]}" [label="{n["label"]}\\n[{n["l"]}]", shape={shp.get(n["kind"], "ellipse")}, style={sty[n["l"]]}];')
            for e in snap['edges']: L.append(f'  "{e["a"]}" -> "{e["b"]}" [label="{e["type"]}", style={sty[e["l"]]}];')
            return '\n'.join(L + ['}'])
        if fmt == 'csv':
            o = io.StringIO(); w = csv.writer(o); w.writerow(['id', 'kind', 'label', 'provenance', 'confidence', 'health', 'ips', 'mac', 'vendor', 'open_ports', 'roles', 'evidence', 'first_seen', 'last_seen'])
            for n in snap['nodes']:
                if n['kind'] == 'service': continue
                w.writerow([n['id'], n['kind'], n['label'], n['l'], n.get('conf'), n.get('health'), ' '.join(n.get('ips', [])), n.get('mac') or '', n.get('vendor') or '', ' '.join(str(p['port']) for p in n.get('ports', [])), ' '.join(n.get('roles', [])), ' '.join(n.get('src', [])), n.get('first', ''), n.get('last', '')])
            return o.getvalue()
        if fmt == 'report': return s.report(full)
        raise ValueError('unknown format')

    def report(s, f):
        T = lambda t: time.strftime('%Y-%m-%d %H:%M:%S UTC', time.gmtime(t)) if t else '-'
        env, n, e = f['environment'] or {}, f['nodes'], f['edges']; hosts = [x for x in n if x['kind'] not in ('service', 'internet', 'dns')]; svc = [x for x in n if x['kind'] == 'service']
        L = [f"# ATLAS FLOW discovery report", f"Generated {f['generated']} by ATLAS FLOW {VERSION} (CyberNyx) on {s.plat['system']} {s.plat['machine']}{' / Android-Termux' if s.plat['termux'] else ''}, Python {s.plat['python']}.", '',
             '## Summary', f"- Assets: **{len(hosts)}**  - Open services: **{len(svc)}**  - Relationships: **{len(e)}**",
             f"- Provenance: " + ', '.join(f"{k} {v}" for k, v in f['stats']['labels'].items()), '', '## Local environment']
        gw = env.get('gateway')
        L += [f"- Gateway: {gw['ip'] + ' on ' + str(gw['iface']) + ' (OBSERVED, ' + gw['src'] + ')' if gw else 'UNKNOWN (no default route readable)'}",
              f"- DNS resolvers: {', '.join(d['ip'] + (' (local stub)' if d['stub'] else '') for d in env.get('dns', {}).get('servers', [])) or 'UNKNOWN'}",
              f"- Neighbor cache: {'readable via ' + ', '.join(env.get('neighbor_src', [])) if env.get('neighbor_readable') else 'UNKNOWN (not readable on this platform)'}", '', '### Interfaces', '| iface | kind | state | MAC | addresses |', '|---|---|---|---|---|']
        for i in env.get('interfaces', []): L.append(f"| {i['name']} | {i['kind']} | {i['state']} | {i['mac'] or 'UNKNOWN'} | {', '.join(a['ip'] + ('/' + str(a['prefix']) if a['prefix'] else '') for a in i['addrs']) or '-'} |")
        L += ['', '## Assets', '| asset | kind | provenance | confidence | health | MAC | vendor | open ports | evidence |', '|---|---|---|---|---|---|---|---|---|']
        for x in sorted(hosts, key=lambda z: z['id']):
            L.append(f"| {x['label']} ({x['id']}) | {x['kind']}{' ' + ','.join(x['roles']) if x['roles'] else ''} | {x['l']} | {x['conf']:.2f} | {x['health']} | {x['mac'] or 'UNKNOWN'} | {x['vendor'] or 'UNKNOWN'} | {', '.join(str(p['port']) + '/' + (p['service'] or '?') for p in x['ports']) or '-'} | {', '.join(x['src'])} |")
        L += ['', '## Relationships', '| from | to | type | provenance | detail |', '|---|---|---|---|---|'] + [f"| {x['a']} | {x['b']} | {x['type']} | {x['l']} | {x['info'] or ''} |" for x in e]
        L += ['', '## Session history'] + [f"- {x['id']} {x['type']} {x['state']} {T(x['started'])} -> {T(x['ended'])} {x.get('summary', '')}" for x in f['sessions']]
        L += ['', '## Audit log (active operations)'] + ([f"- {T(a['t'])} {a['msg']}" for a in f['audit']] or ['- none: no active operation was performed'])
        L += ['', '## Method and limits', '- OBSERVED = read from OS tables, packets or connect() results. DETECTED = inferred (OUI vendor from an embedded subset, service name from port number, subnet adjacency, default-route-implied Internet). UNKNOWN = not determinable here.',
              f"- Confidence = 1 - prod(1 - w) over distinct evidence sources, weights {json.dumps(WEIGHT)}. It measures evidence strength, not security posture.",
              '- Active probing is limited to TCP connect() inside an operator-authorized private scope. Hosts that drop all probes and are absent from the neighbor cache are not discoverable by this tool.',
              '- No OS fingerprinting, banner grabbing, payload capture or exploitation is performed. Service names are guesses from port numbers.']
        return '\n'.join(L)


# ---------------------------------------------------------------- passive, metadata-only listener
class Listener:
    def __init__(s, eng):
        s.E = eng; s.running = False; s.reset()

    def reset(s):
        s.lk = threading.RLock(); s.stop_evt = threading.Event(); s.threads, s.socks = [], []
        s.src = {}; s.rawok = False; s.events = 0; s.bytes = 0; s.protos = Counter(); s.by_src = Counter(); s.hosts = {}; s.conns = {}; s.dropped = 0
        s.feed = deque(maxlen=400); s.tl = deque(maxlen=300); s.ifs = {}; s.started = None; s.ended = None; s.sid = None; s._tok = 0; s._tt = 0; s.iface = 'any'

    def caps(s):
        P = s.E.plat; c = {}
        try:
            sk = socket.socket(socket.AF_PACKET, socket.SOCK_RAW, socket.ntohs(3)); sk.close(); c['raw'] = dict(ok=True, why='AF_PACKET available: frame headers (metadata only) from all interfaces')
        except AttributeError: c['raw'] = dict(ok=False, why='AF_PACKET not supported by this OS/Python')
        except OSError as e: c['raw'] = dict(ok=False, why=f'{e.strerror or e}. Needs root / CAP_NET_RAW (not available to unprivileged Termux)')
        c['netdev'] = dict(ok=read_netdev() is not None, why='/proc/net/dev interface counters' if read_netdev() is not None else '/proc/net/dev not readable')
        c['sockets'] = dict(ok=read_sockets() is not None, why='this host\'s established TCP connections (/proc/net/tcp)' if read_sockets() is not None else '/proc/net/tcp not readable (Android 10+ restricts it)')
        c['neighbors'] = dict(ok=bool(read_neighbors()[1]), why='OS neighbor cache polling' if read_neighbors()[1] else 'neighbor cache not readable here')
        c['mdns'] = dict(ok=True, why='multicast group listener 224.0.0.251:5353 (may be filtered by Wi-Fi power-save/OS on Android)')
        c['ssdp'] = dict(ok=True, why='multicast group listener 239.255.255.250:1900 (device announcements)')
        return c

    def start(s, iface='any'):
        if s.running: raise RuntimeError('listen is already running')
        s.reset(); s.running = True; s.started = time.time(); s.iface = iface or 'any'; s.sid = time.strftime('l-%Y%m%d-%H%M%S'); caps = s.caps()
        raw_ok = False
        if caps['raw']['ok']:
            try:
                sk = socket.socket(socket.AF_PACKET, socket.SOCK_RAW, socket.ntohs(3)); sk.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 8 << 20)
                if s.iface != 'any': sk.bind((s.iface, 0))
                sk.settimeout(0.4); s.socks.append(sk); s._spawn(s._raw_loop, sk); s.src['raw'] = dict(state='active', why=caps['raw']['why']); raw_ok = True
            except OSError as e: s.src['raw'] = dict(state='unavailable', why=str(e))
        else: s.src['raw'] = dict(state='unavailable', why=caps['raw']['why'])
        s.rawok = raw_ok
        for name, fn in (('mdns', s._mdns_loop), ('ssdp', s._ssdp_loop)):
            try: sk = s._mcast(5353 if name == 'mdns' else 1900, '224.0.0.251' if name == 'mdns' else '239.255.255.250'); s.socks.append(sk); s._spawn(fn, sk); s.src[name] = dict(state='active', why=caps[name]['why'] + (' (names only; counts come from raw frames)' if raw_ok else ''))
            except OSError as e: s.src[name] = dict(state='unavailable', why=str(e))
        for name, fn in (('netdev', s._netdev_loop), ('sockets', s._sock_loop), ('neighbors', s._nbr_loop)):
            if caps[name]['ok']: s._spawn(fn); s.src[name] = dict(state='active', why=caps[name]['why'])
            else: s.src[name] = dict(state='unavailable', why=caps[name]['why'])
        if not any(v['state'] == 'active' for v in s.src.values()): s.running = False; raise RuntimeError('no passive source is available on this platform with current permissions')
        s.E.ev('LISTEN', 'listen started: ' + ', '.join(k for k, v in s.src.items() if v['state'] == 'active'), OBS)

    def _spawn(s, fn, *a): t = threading.Thread(target=fn, args=a, daemon=True); t.start(); s.threads.append(t)

    def _mcast(s, port, grp):
        sk = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP); sk.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        if hasattr(socket, 'SO_REUSEPORT'):
            try: sk.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEPORT, 1)
            except OSError: pass
        sk.bind(('', port)); sk.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, socket.inet_aton(grp) + socket.inet_aton('0.0.0.0')); sk.settimeout(0.5); return sk

    def stop(s):
        if not s.running: return
        s.running = False; s.stop_evt.set(); s.ended = time.time()
        for sk in s.socks:
            try: sk.close()
            except Exception: pass
        s.E.ev('LISTEN', f'listen stopped: {s.events} events, {len(s.hosts)} hosts, {len(s.conns)} connections', OBS)
        s.E._save_session(dict(id=s.sid, type='listen', started=s.started, ended=s.ended, state='stopped', opts=dict(iface=s.iface)), listen=dict(s.brief(), protocols=dict(s.protos.most_common(20))))

    # ---- core metadata sink (no payload ever reaches here)
    def note(s, ts, source, proto, src, dst, sp, dp, ln, mac=None):
        with s.lk:
            s.events += 1; s.bytes += ln; s.protos[proto] += 1; s.by_src[source] += 1
            sec = int(ts)
            if s.tl and s.tl[-1][0] == sec: s.tl[-1][1] += 1
            else: s.tl.append([sec, 1])
            if ts - s._tt >= 1: s._tt, s._tok = ts, 40            # sampled feed: <=40 rows/s; counters stay exact
            if s._tok > 0: s._tok -= 1; s.feed.append(dict(t=ts, src=src, dst=dst, sp=sp, dp=dp, proto=proto, len=ln, via=source))
            for ip, out in ((src, True), (dst, False)):
                if not ip: continue
                h = s.hosts.get(ip)
                if not h:
                    if len(s.hosts) >= 4000: s.dropped += 1; continue
                    h = s.hosts[ip] = dict(ip=ip, first=ts, last=ts, out=0, inn=0, pk=0, protos=Counter(), macs=set())
                h['last'] = ts; h['pk'] += 1; h['protos'][proto] += 1; h['out' if out else 'inn'] += ln
            if mac and src in s.hosts: s.hosts[src]['macs'].add(mac)
            if src and dst:
                k = (proto, src, dst, dp); c = s.conns.get(k)
                if not c:
                    if len(s.conns) >= 6000: s.dropped += 1; return
                    c = s.conns[k] = dict(proto=proto, src=src, dst=dst, dp=dp, first=ts, last=ts, n=0, by=0, via=set())
                c['last'] = ts; c['n'] += 1; c['by'] += ln; c['via'].add(source)

    def _publish(s, src, dst, mac, via, confirm=True, link_mac=False):
        E = s.E
        if src and E.is_priv(src): E.observe(src, 'passive', mac=mac if link_mac else None, confirm=confirm)
        if src and dst: E.flow(src, dst, 1, 0, via)

    def _raw_loop(s, sk):
        S, dis = s.E.S, s.E._dissect
        nets = [ipaddress.ip_network(x['net']) for x in (s.E.env or s.E.read_env())['subnets']]
        lastpub = {}
        while s.running:
            try: data, addr = sk.recvfrom(65535)
            except socket.timeout: continue
            except OSError: break
            hat, pkt = addr[3] if len(addr) > 3 else 1, addr[2] if len(addr) > 2 else 0
            if addr[0] == 'lo' and pkt == 4: continue
            lt = {1: 1, 772: 1, 803: 127, 801: 105, 65534: 101, 519: 101}.get(hat, 1); ts = time.time()
            d = dis(data[:2048], lt)                                    # only headers are inspected; the slice and `data` are dropped right after
            proto, src, dst = d.get('label') or d.get('tp') or '?', d.get('src', ''), d.get('dst', '')
            if not src: s.note(ts, 'raw', proto, '', '', 0, 0, len(data)); continue
            smac = d.get('smac')
            onlink = d.get('tp') == 'ARP' or (smac and src and ':' not in src and any(ipaddress.ip_address(src) in n for n in nets))
            s.note(ts, 'raw', proto, src, dst, d.get('sp', 0), d.get('dp', 0), len(data), smac if onlink else None)
            if ts - lastpub.get(src, 0) > 1.0: lastpub[src] = ts; s._publish(src, dst, smac, 'listen', True, bool(onlink))
            del data, d

    def _mdns_loop(s, sk):
        while s.running:
            try: data, a = sk.recvfrom(9000)
            except socket.timeout: continue
            except OSError: break
            ts, ip = time.time(), norm_ip(a[0])
            if not s.rawok: s.note(ts, 'mdns', 'mDNS', ip, '224.0.0.251', a[1], 5353, len(data))
            names, svc = parse_mdns(data, s.E.dname); del data
            if ip and s.E.is_priv(ip):
                nm = next((n for n, ips in names.items() if ip in ips), None)
                x = s.E.observe(ip, 'mdns', name=nm, name_src='mDNS announcement')
                if x and svc: x['mdns'].update(svc)

    def _ssdp_loop(s, sk):
        while s.running:
            try: data, a = sk.recvfrom(4096)
            except socket.timeout: continue
            except OSError: break
            ts, ip = time.time(), norm_ip(a[0])
            if not s.rawok: s.note(ts, 'ssdp', 'SSDP', ip, '239.255.255.250', a[1], 1900, len(data))
            p = parse_ssdp(data); del data
            if ip and s.E.is_priv(ip):
                s.E.observe(ip, 'ssdp', extra=({'ssdp_server': p['server']} if p and p.get('server') else None))

    def _netdev_loop(s):
        prev, pt = None, 0
        while s.running and not s.stop_evt.wait(1.0):
            cur, t = read_netdev(), time.time()
            if cur is None: continue
            with s.lk:
                for n, v in cur.items():
                    p = (prev or {}).get(n); o = s.ifs.setdefault(n, dict(name=n, rx_b=0, tx_b=0, rx_p=0, tx_p=0, rx_rate=0, tx_rate=0, first=v, hist=deque(maxlen=60)))
                    if p and t > pt: o['rx_rate'] = (v['rx_b'] - p['rx_b']) / (t - pt); o['tx_rate'] = (v['tx_b'] - p['tx_b']) / (t - pt); o['hist'].append(o['rx_rate'] + o['tx_rate'])
                    o.update(rx_b=v['rx_b'] - o['first']['rx_b'], tx_b=v['tx_b'] - o['first']['tx_b'], rx_p=v['rx_p'] - o['first']['rx_p'], tx_p=v['tx_p'] - o['first']['tx_p'], drops=v['rx_d'] + v['tx_d'], errs=v['rx_e'] + v['tx_e'])
            prev, pt = cur, t

    def _sock_loop(s):
        seen = {}
        while s.running and not s.stop_evt.wait(2.0):
            rows = read_sockets()
            if rows is None: continue
            ts = time.time()
            for st, lip, lp, rip, rp in rows:
                if st != '01' or not lip or not rip or rip in ('127.0.0.1', '::1'): continue
                k = (lip, lp, rip, rp)
                if k not in seen:
                    seen[k] = ts; s.note(ts, 'sockets', 'TCP', lip, rip, lp, rp, 0)
                    if s.E.is_priv(rip) is False: s.E.flow(lip, rip, 1, 0, 'sockets')

    def _nbr_loop(s):
        while s.running and not s.stop_evt.wait(5.0):
            n = s.E.refresh_neighbors()
            if n: s.note(time.time(), 'neighbors', 'ARP/ND', '', '', 0, 0, 0)

    # ---- views
    def brief(s):
        with s.lk:
            return dict(running=s.running, sid=s.sid, started=s.started, ended=s.ended, events=s.events, hosts=len(s.hosts), conns=len(s.conns), bytes=s.bytes, dropped=s.dropped, iface=s.iface,
                        sources={k: v['state'] for k, v in s.src.items()})

    def view(s):
        with s.lk:
            now = time.time(); hosts = sorted(s.hosts.values(), key=lambda h: -(h['out'] + h['inn']))[:300]
            cons = sorted(s.conns.values(), key=lambda c: -c['n'])[:300]
            return dict(brief=s.brief(), sources=s.src, protocols=s.protos.most_common(16), timeline=list(s.tl), feed=list(s.feed)[-120:],
                        hosts=[dict(ip=h['ip'], first=h['first'], last=h['last'], pk=h['pk'], out=h['out'], inn=h['inn'], protos=h['protos'].most_common(4), macs=sorted(h['macs'])[:2], scope='local' if s.E.is_priv(h['ip']) else 'external') for h in hosts],
                        conns=[dict(proto=c['proto'], src=c['src'], dst=c['dst'], dp=c['dp'], first=c['first'], last=c['last'], n=c['n'], by=c['by'], via=sorted(c['via'])) for c in cons],
                        ifaces=[dict(name=i['name'], kind=iface_kind(i['name']), rx_b=i['rx_b'], tx_b=i['tx_b'], rx_p=i['rx_p'], tx_p=i['tx_p'], rx_rate=i['rx_rate'], tx_rate=i['tx_rate'], hist=list(i['hist']), drops=i.get('drops', 0), errs=i.get('errs', 0)) for i in s.ifs.values()],
                        privacy='Payload bytes are never stored or shown. Only addresses, ports, protocol labels, sizes and timestamps are kept; the feed is sampled.', now=now)
