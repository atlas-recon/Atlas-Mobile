/* ATLAS FLOW · CyberNyx — DISCOVERY + LISTEN views. Extends the existing Graph class; every datum shown comes from /api/discovery or /api/listen. */
const PREF={get(k,d){try{const v=localStorage.getItem('atlas.'+k);return v===null?d:JSON.parse(v)}catch(e){return d}},set(k,v){try{localStorage.setItem('atlas.'+k,JSON.stringify(v))}catch(e){}}};
const LBL=['OBSERVED','DETECTED','UNKNOWN'],lb=l=>`<span class="lb ${l}" title="${l=='OBSERVED'?'read directly from OS tables, packets or connect() results':l=='DETECTED'?'inferred from an observed fact':'could not be determined here'}">${l}</span>`;
const fAgo=t=>{if(!t)return'-';const d=Math.max(0,Date.now()/1000-t);return d<2?'now':d<90?Math.round(d)+'s ago':d<5400?Math.round(d/60)+'m ago':Math.round(d/3600)+'h ago'};
const fRate=b=>b<1024?b.toFixed(0)+' B/s':b<1048576?(b/1024).toFixed(1)+' KB/s':(b/1048576).toFixed(2)+' MB/s';
const toast=(m,cls)=>{let t=$('#toast');if(!t){t=document.createElement('div');t.id='toast';document.body.appendChild(t)}t.className='on '+(cls||'');t.textContent=m;clearTimeout(t._t);t._t=setTimeout(()=>t.className='',3800)};
const fx=()=>PREF.get('fx',true)&&matchMedia('(prefers-reduced-motion:no-preference)').matches;
const DSTATE={snap:null,rev:-1,seq:0,events:[],env:null,sessions:null,dock:'feed',job:null};
const TIER={internet:0,gateway:1,dns:1,self:2,host:2,service:3};

/* ================= DGraph: discovery topology on top of the existing Graph (pan/zoom/drag/hit-test are inherited) ================= */
class DGraph extends Graph{
 constructor(cv,onsel){super(cv,'disc',onsel);Object.assign(this,{emap:new Map(),F:{labels:{OBSERVED:1,DETECTED:1,UNKNOWN:1},kind:'',health:'',q:''},focus:null,path:null,pathE:null,tgt:null,job:null,fam:getComputedStyle(document.body).fontFamily,userMoved:false,sparks:0,spawnT:0});
  ['mousedown','wheel','touchstart'].forEach(ev=>cv.addEventListener(ev,()=>{this.fit=0;this.tgt=null;this.userMoved=true},{passive:true}));this.bindTouch();
  cv.addEventListener('dblclick',e=>{const r=cv.getBoundingClientRect(),h=this.hit(e.clientX-r.left,e.clientY-r.top);if(h&&h.kind){this.sel=h;this.onsel(h);this.focusOn(h.id)}else this.clearFocus()});
  cv.addEventListener('click',e=>{if(e.shiftKey&&DSTATE.prevSel&&this.sel&&DSTATE.prevSel.kind&&this.sel.kind&&DSTATE.prevSel!==this.sel)this.tracePath(DSTATE.prevSel.id,this.sel.id)})}
 bindTouch(){const cv=this.cv;let t0=null,pin=null,mv=0;const P=e=>{const r=cv.getBoundingClientRect();return[...e.touches].map(t=>[t.clientX-r.left,t.clientY-r.top])};
  cv.addEventListener('touchstart',e=>{e.preventDefault();const p=P(e);mv=0;if(p.length==1){t0={x:p[0][0],y:p[0][1],ox:this.ox,oy:this.oy,h:this.hit(p[0][0],p[0][1])};pin=null}else if(p.length==2){pin={d:Math.hypot(p[0][0]-p[1][0],p[0][1]-p[1][1]),k:this.k};t0=null}},{passive:false});
  cv.addEventListener('touchmove',e=>{e.preventDefault();const p=P(e);if(p.length==1&&t0){const dx=p[0][0]-t0.x,dy=p[0][1]-t0.y;mv+=Math.abs(dx)+Math.abs(dy);if(t0.h&&t0.h.kind&&mv>8){const[x,y]=this.tw(p[0][0],p[0][1]);t0.h.x=x;t0.h.y=y;t0.h.vx=t0.h.vy=0;this.alpha=Math.max(this.alpha,.3)}else if(!(t0.h&&t0.h.kind)){this.ox=t0.ox+dx;this.oy=t0.oy+dy}}else if(p.length==2&&pin){const d=Math.hypot(p[0][0]-p[1][0],p[0][1]-p[1][1]);this.k=Math.max(.15,Math.min(6,pin.k*d/pin.d))}},{passive:false});
  cv.addEventListener('touchend',e=>{e.preventDefault();if(t0&&mv<10){const h=t0.h;this.sel=h;this.onsel&&this.onsel(h)}t0=null;pin=null},{passive:false})}
 textOf(n){return[n.id,n.label,n.mac,n.vendor,n.ip,(n.ips||[]).join(' '),n.service,n.port,n.kind,(n.roles||[]).join(' '),(n.ports||[]).map(p=>p.port+' '+(p.service||'')).join(' '),(n.attrs||[]).map(a=>a.v).join(' ')].join(' ').toLowerCase()}
 vis(n){const F=this.F;return!!F.labels[n.l]&&(!F.kind||n.kind==F.kind||(F.kind=='host'&&n.kind=='self'))&&(!F.health||n.health==F.health)}
 alp(n){let a=this.vis(n)?1:.1;if(this.F.q)a*=n._t.includes(this.F.q)?1:.16;if(this.focus&&!this.focus.has(n.id))a*=.12;return a}
 ingest(d){const now=performance.now(),seen=new Set(),gw=d.gateway&&this.nodes.get(d.gateway.ip);let born=0;this.job=d.job;
  d.nodes.forEach(n=>{seen.add(n.id);let o=this.nodes.get(n.id);if(!o){const par=n.kind=='service'?this.nodes.get(n.parent):gw;const px=par?par.x:0,py=par?par.y:0;o={x:px+(Math.random()-.5)*60,y:py+20+Math.random()*30,vx:0,vy:0,born:now};this.nodes.set(n.id,o);born++}Object.assign(o,n);o._t=this.textOf(n)});
  for(const k of[...this.nodes.keys()])if(!seen.has(k))this.nodes.delete(k);
  const es=[];d.edges.forEach(e=>{const A=this.nodes.get(e.a),B=this.nodes.get(e.b);if(!A||!B)return;let o=this.emap.get(e.id);const old=o?o.n:e.n;if(!o){o={born:now};this.emap.set(e.id,o)}Object.assign(o,e,{A,B,dn:e.n-old});es.push(o)});
  for(const k of[...this.emap.keys()])if(!d.edges.some(e=>e.id==k))this.emap.delete(k);this.edges=es;
  if(born){this.alpha=Math.max(this.alpha,.6);if(!this.userMoved)this.fit=70}
  if(this.sel&&this.nodes.has(this.sel.id))this.sel=this.nodes.get(this.sel.id)}
 relayout(){this.nodes.forEach(n=>{n.x=(Math.random()-.5)*300;n.y=(Math.random()-.5)*200;n.vx=n.vy=0});this.alpha=1;this.userMoved=false;this.fit=120;this.tgt=null}
 fitView(){const ns=[...this.nodes.values()];if(!ns.length)return;let a=1e9,b=1e9,c=-1e9,d=-1e9;ns.forEach(n=>{a=Math.min(a,n.x);c=Math.max(c,n.x);b=Math.min(b,n.y);d=Math.max(d,n.y)});const w=c-a+200,h=d-b+60,k=Math.min(2,this.W/w,Math.max(40,this.H-120)/h);this.k=k;this.ox=-(a+c)/2*k;this.oy=-(b+d)/2*k+4}
 viewTo(ids){const ns=ids.map(i=>this.nodes.get(i)).filter(Boolean);if(!ns.length)return;let a=1e9,b=1e9,c=-1e9,d=-1e9;ns.forEach(n=>{a=Math.min(a,n.x);c=Math.max(c,n.x);b=Math.min(b,n.y);d=Math.max(d,n.y)});const w=c-a+260,h=d-b+120,k=Math.min(2.2,this.W/w,Math.max(40,this.H-120)/h);this.fit=0;this.userMoved=true;this.tgt={k,ox:-(a+c)/2*k,oy:-(b+d)/2*k+4}}
 nbrs(id){const s=new Set([id]);this.edges.forEach(e=>{if(e.a==id)s.add(e.b);if(e.b==id)s.add(e.a)});return s}
 focusOn(id){this.focus=this.nbrs(id);this.viewTo([...this.focus]);dUI.sync()}
 clearFocus(){this.focus=null;this.path=null;this.pathE=null;dUI.sync()}
 tracePath(a,b){const adj=new Map();this.edges.forEach(e=>{(adj.get(e.a)||adj.set(e.a,[]).get(e.a)).push([e.b,e]);(adj.get(e.b)||adj.set(e.b,[]).get(e.b)).push([e.a,e])});
  const prev=new Map([[a,null]]),q=[a];while(q.length){const u=q.shift();if(u==b)break;for(const[v,e]of adj.get(u)||[])if(!prev.has(v)){prev.set(v,[u,e]);q.push(v)}}
  if(!prev.has(b)){this.path=null;this.pathE=null;toast('no relationship path between those assets in the observed graph');dUI.sync();return null}
  const ids=[],es=[];let c=b;while(c!=null){ids.unshift(c);const p=prev.get(c);if(p){es.unshift(p[1])}c=p?p[0]:null}this.path=ids;this.pathE=new Set(es.map(e=>e.id));this.focus=new Set(ids);this.viewTo(ids);dUI.sync();return{ids,es}}
 step(){const ns=[...this.nodes.values()],a=this.alpha;
  if(this.tgt){const t=this.tgt;this.k+=(t.k-this.k)*.16;this.ox+=(t.ox-this.ox)*.16;this.oy+=(t.oy-this.oy)*.16;if(Math.abs(t.k-this.k)<.002&&Math.abs(t.ox-this.ox)<.5&&Math.abs(t.oy-this.oy)<.5)this.tgt=null}
  if(a>=.01){const TY={internet:-190,gateway:-45,dns:-110,self:55,host:55,service:150},REST={service:48,lan:130,uplink:110,route:110,resolver:120,flow:150,'flow-ext':170};
   for(let i=0;i<ns.length;i++){const p=ns[i];for(let j=i+1;j<ns.length;j++){const q=ns[j];let dx=p.x-q.x,dy=p.y-q.y,d2=dx*dx+dy*dy+.5;if(d2>120000)continue;const sv=p.kind=='service'&&q.kind=='service',same=p.kind==q.kind&&p.kind!='service',f=(sv?500:same?9000:2800)/d2*a,d=Math.sqrt(d2);dx/=d;dy/=d;p.vx+=dx*f;p.vy+=dy*f*.4;q.vx-=dx*f;q.vy-=dy*f*.4}
    if(p.kind=='service'){const par=this.nodes.get(p.parent);if(par){p.vx+=(par.x-p.x)*.02*a;p.vy+=(par.y+70-p.y)*.05*a}}else p.vy+=(TY[p.kind]-p.y)*.045*a;
    if(p.kind=='internet'||p.kind=='gateway')p.vx+=(0-p.x)*.06*a;else p.vx-=p.x*.003*a}
   this.edges.forEach(e=>{const A=e.A,B=e.B;if(A===B)return;const dx=B.x-A.x,dy=B.y-A.y,d=Math.sqrt(dx*dx+dy*dy)+.01,s=(e.type=='flow'||e.type=='flow-ext')?.006:.03,f=(d-(REST[e.type]||110))*s*a;A.vx+=dx/d*f;A.vy+=dy/d*f*.3;B.vx-=dx/d*f;B.vy-=dy/d*f*.3});
   ns.forEach(n=>{if(n===this.drag)return;n.vx*=.8;n.vy*=.8;const s=Math.hypot(n.vx,n.vy);if(s>12){n.vx*=12/s;n.vy*=12/s}n.x+=n.vx;n.y+=n.vy});this.alpha*=.994}
  if(this.fit>0){this.fit--;this.fitView()}}
 spawn(){if(!fx()||!this.pulse||this.pulses.length>90||!this.edges.length)return;const now=performance.now(),run=this.job&&this.job.state=='running';
  this.edges.forEach(e=>{if(e.dn>0&&(e.type=='flow'||e.type=='flow-ext')){for(let i=0;i<Math.min(3,e.dn);i++)this.pulses.push({e,t:i*-.12,dir:1,s:.012+Math.random()*.01});e.dn=0}if(now-e.born<900&&!e._p){e._p=1;this.pulses.push({e,t:0,dir:1,s:.02})}});
  if(run&&now-this.spawnT>140){this.spawnT=now;const c=this.edges.filter(e=>e.type=='lan'||e.type=='service'||e.type=='route');if(c.length)this.pulses.push({e:c[Math.random()*c.length|0],t:0,dir:Math.random()<.7?1:-1,s:.014+Math.random()*.01})}}
 shape(c,n,x,y,r){c.beginPath();const k=n.kind;if(k=='gateway'){c.moveTo(x,y-r-2);c.lineTo(x+r+2,y);c.lineTo(x,y+r+2);c.lineTo(x-r-2,y);c.closePath()}else if(k=='internet'){for(let i=0;i<6;i++){const a=Math.PI/3*i;c[i?'lineTo':'moveTo'](x+Math.cos(a)*(r+2),y+Math.sin(a)*(r+2))}c.closePath()}else if(k=='dns'){c.moveTo(x,y-r-1);c.lineTo(x+r+1,y+r);c.lineTo(x-r-1,y+r);c.closePath()}else if(k=='service'){c.rect(x-r,y-r,2*r,2*r)}else c.arc(x,y,r,0,6.2832)}
 draw(){const c=this.c,now=performance.now(),k=this.k,W=this.W,H=this.H;c.clearRect(0,0,W,H);c.lineCap='round';const run=this.job&&this.job.state=='running',F=fx();
  const anchor=[...this.nodes.values()].find(n=>n.kind=='self')||this.nodes.get('internet');
  if(run&&F&&anchor){const x=this.sx(anchor),y=this.sy(anchor),a=(now/2600)%1*6.2832;for(let i=1;i<=3;i++){c.strokeStyle='rgba(63,182,122,'+(.10-i*.02)+')';c.lineWidth=1;c.beginPath();c.arc(x,y,70*i*Math.max(.6,k),0,6.2832);c.stroke()}
   if(c.createConicGradient){const g=c.createConicGradient(a,x,y);g.addColorStop(0,'rgba(63,182,122,.20)');g.addColorStop(.12,'rgba(63,182,122,0)');g.addColorStop(1,'rgba(63,182,122,0)');c.fillStyle=g;c.beginPath();c.arc(x,y,210*Math.max(.6,k),0,6.2832);c.fill()}}
  const EC={flow:'63,182,122','flow-ext':'63,182,122',lan:'123,142,132',service:'79,152,115',uplink:'214,224,218',route:'159,217,184',resolver:'212,162,74'};
  this.edges.forEach(e=>{const A=e.A,B=e.B,ax=this.sx(A),ay=this.sy(A),p=Math.min(1,(now-e.born)/(F?700:1)),bx=ax+(this.sx(B)-ax)*p,by=ay+(this.sy(B)-ay)*p,al=Math.min(this.alp(A),this.alp(B)),on=this.sel===e||this.hover===e,pe=this.pathE&&this.pathE.has(e.id);
   c.setLineDash(e.l=='OBSERVED'?[]:e.l=='DETECTED'?[6,4]:[2,4]);c.strokeStyle=pe?TH.hi:on?TH.g2:`rgba(${EC[e.type]||'123,142,132'},${(e.type=='lan'?.4:.65)*al})`;c.lineWidth=((e.type.startsWith('flow')?.8+Math.log10(e.n+1)*.5:1)*(pe||on?2:1));
   c.beginPath();c.moveTo(ax,ay);c.lineTo(bx,by);c.stroke();c.setLineDash([]);
   if((on||pe)&&p>=1){const t=e.type+' · '+e.l,x=(ax+bx)/2,y=(ay+by)/2;c.font='10.5px '+this.fam;c.fillStyle=TH.bg;c.fillRect(x-3,y-11,c.measureText(t).width+8,15);c.fillStyle=TH.hi;c.fillText(t,x+1,y)}});
  this.pulses=this.pulses.filter(p=>{p.t+=p.s;if(p.t>=1)return false;if(p.t<0)return true;const A=p.dir>0?p.e.A:p.e.B,B=p.dir>0?p.e.B:p.e.A,x=this.sx(A)+(this.sx(B)-this.sx(A))*p.t,y=this.sy(A)+(this.sy(B)-this.sy(A))*p.t;c.fillStyle=TH.g2;c.globalAlpha=.9*Math.min(this.alp(A),this.alp(B));c.beginPath();c.arc(x,y,2,0,6.3);c.fill();c.globalAlpha=1;return true});
  c.font='10.5px '+this.fam;const HA={ACTIVE:1,SELF:1,IDLE:.72,CACHED:.5,STALE:.4,UNKNOWN:.35},HC={ACTIVE:TH.g,SELF:TH.g2,IDLE:TH.am,CACHED:TH.mu,STALE:TH.mu,UNKNOWN:TH.mu},BR={internet:13,gateway:10,self:9,host:7.5,dns:7,service:4.2};
  this.nodes.forEach(n=>{const x=this.sx(n),y=this.sy(n);if(x<-40||y<-40||x>W+40||y>H+40)return;const al=this.alp(n),zs=Math.min(1.6,Math.max(.7,k)),r=(BR[n.kind]||7)*zs,s=this.sel===n,hv=this.hover===n,age=now-(n.born||0);c.globalAlpha=al;
   if(F&&age<1700){c.strokeStyle=TH.g;c.globalAlpha=al*(1-age/1700);c.lineWidth=1.5;c.beginPath();c.arc(x,y,r+4+age/1700*34,0,6.3);c.stroke();c.globalAlpha=al}
   const fa=HA[n.health]??.5,col=n.kind=='internet'?null:n.kind=='dns'?TH.am:n.kind=='service'?'#3b7a5a':n.kind=='gateway'||n.kind=='self'?TH.g2:TH.g;
   this.shape(c,n,x,y,r);if(col){c.globalAlpha=al*fa*(n.kind=='service'?1:.9);c.fillStyle=col;c.fill();c.globalAlpha=al}else{c.fillStyle='rgba(214,224,218,.07)';c.fill()}
   c.setLineDash(n.l=='OBSERVED'?[]:n.l=='DETECTED'?[3,2]:[1,3]);c.lineWidth=n.kind=='service'?.8:1.3;c.strokeStyle=n.kind=='internet'?TH.fg:n.kind=='dns'?TH.am:TH.g2;c.stroke();c.setLineDash([]);
   if(n.kind=='self'){c.fillStyle=TH.bg;c.beginPath();c.arc(x,y,r*.38,0,6.3);c.fill()}
   if(n.kind!='service'&&n.conf!=null&&k>.45){c.strokeStyle=n.conf>.75?TH.g2:n.conf>.5?TH.g:TH.am;c.lineWidth=1.6;c.beginPath();c.arc(x,y,r+4.5,-1.5708,-1.5708+6.2832*n.conf);c.stroke()}
   if(n.kind!='service'&&n.kind!='internet'){c.fillStyle=HC[n.health]||TH.mu;c.beginPath();c.arc(x+r*.85,y-r*.85,2.6,0,6.3);c.fill()}
   if(this.F.q&&n._t.includes(this.F.q)){c.strokeStyle=TH.hi;c.lineWidth=1.2;c.beginPath();c.arc(x,y,r+9,0,6.3);c.stroke()}
   if(this.path&&this.path.includes(n.id)){c.strokeStyle=TH.hi;c.lineWidth=2;c.beginPath();c.arc(x,y,r+7,0,6.3);c.stroke()}
   if(s){c.strokeStyle=TH.hi;c.lineWidth=1.2;const q=r+9;[[-1,-1],[1,-1],[1,1],[-1,1]].forEach(([a,b])=>{c.beginPath();c.moveTo(x+a*q,y+b*(q-5));c.lineTo(x+a*q,y+b*q);c.lineTo(x+a*(q-5),y+b*q);c.stroke()})}
   if(s||hv||(n.kind!='service'&&k>.55)||k>1.2){const t=(n.label||n.id).toString(),tt=t.length>24?t.slice(0,23)+'…':t;c.fillStyle=s||hv?TH.hi:'rgba(214,224,218,.82)';c.fillText(tt,x+r+6,y+3);if((s||hv)&&n.vendor){c.fillStyle=TH.mu;c.fillText(n.vendor,x+r+6,y+15)}}
   c.globalAlpha=1});
  if(!this.nodes.size){c.fillStyle=TH.mu;c.font='12px '+this.fam;c.textAlign='center';c.fillText('no assets yet — start discovery',W/2,H/2);c.textAlign='left'}}
}

/* ================= DISCOVERY view ================= */
const dUI={};
function buildDiscovery(){
 const sec=document.createElement('section');sec.className='v';sec.id='v-discovery';
 sec.innerHTML=`<div class="dwrap">
 <div class="dbar">
  <button id="dStart" class="pri" title="S">▶ start discovery</button>
  <label class="chk" title="active TCP-connect sweep, only inside an authorized private scope"><input type="checkbox" id="dSweep"> authorized sweep</label>
  <button id="dAuth" title="attest authorization for a subnet">authorize scope…</button>
  <span id="dProg" class="dprog"></span><span class="grow"></span>
  <select id="dExp" title="E = JSON"><option value="">export ▾</option><option value="json">JSON (full)</option><option value="topology">topology JSON</option><option value="dot">Graphviz DOT</option><option value="csv">assets CSV</option><option value="report">session report (md)</option><option value="png">graph image (PNG)</option></select>
  <button id="dHelp" title="?">⌨ keys</button></div>
 <div class="dmain"><div class="gwrap" id="dgw"><canvas id="dcv"></canvas>
  <div class="dtool"><input id="dq" placeholder="search assets  /" ><span id="dchips"></span>
   <select id="dKind"><option value="">all kinds</option><option>self</option><option>gateway</option><option>host</option><option>service</option><option>dns</option><option>internet</option></select>
   <select id="dHealth"><option value="">any health</option><option>ACTIVE</option><option>IDLE</option><option>STALE</option><option>CACHED</option></select>
   <button id="dFit" title="R">fit</button><button id="dFocus" title="X">focus</button><button id="dReset" title="Shift+R">re-layout</button><button id="dPulse" title="P">pulses</button><button id="dFs" title="F">⛶ fullscreen</button><button id="dFsRun" class="pri fsonly">▶</button></div>
  <div class="dhud" id="dhud"></div>
  <div class="leg dleg"><span class="lb OBSERVED">━ OBSERVED</span><span class="lb DETECTED">┅ DETECTED</span><span class="lb UNKNOWN">┈ UNKNOWN</span><span>◆ gateway</span><span>⬡ internet</span><span>▲ dns</span><span>▪ service</span><span>ring = confidence</span><span>dot = health</span></div>
  <div class="dins pn" id="dins"></div>
  <div class="empty" id="dEmpty"></div></div>
  <div class="dock pn" id="dock"><div class="dtabs" id="dtabs"></div><div class="dbody" id="dbody"></div></div></div></div>`;
 $('main').appendChild(sec);
 dUI.cv=$('#dcv');dUI.gw=$('#dgw');
 window.DG=new DGraph(dUI.cv,h=>{DSTATE.prevSel=DSTATE.cur;DSTATE.cur=h;dInspect(h)});
 $('#dchips').innerHTML=LBL.map(l=>`<button class="chip on ${l}" data-l="${l}" title="toggle ${l}">${l[0]+l.slice(1).toLowerCase()}<b></b></button>`).join('');
 $('#dchips').onclick=e=>{const b=e.target.closest('[data-l]');if(!b)return;DG.F.labels[b.dataset.l]=DG.F.labels[b.dataset.l]?0:1;b.classList.toggle('on',!!DG.F.labels[b.dataset.l]);dUI.sync()};
 let qt;$('#dq').oninput=e=>{clearTimeout(qt);qt=setTimeout(()=>{DG.F.q=e.target.value.trim().toLowerCase();dUI.sync()},120)};
 $('#dKind').onchange=e=>{DG.F.kind=e.target.value;dUI.sync()};$('#dHealth').onchange=e=>{DG.F.health=e.target.value;dUI.sync()};
 $('#dFit').onclick=()=>{DG.userMoved=false;DG.tgt=null;DG.fitView()};$('#dFocus').onclick=dToggleFocus;$('#dReset').onclick=()=>DG.relayout();
 $('#dPulse').onclick=()=>{DG.pulse=!DG.pulse;if(!DG.pulse)DG.pulses=[];dUI.sync()};$('#dFs').onclick=dFullscreen;$('#dStart').onclick=dStartStop;$('#dFsRun').onclick=dStartStop;
 $('#dAuth').onclick=()=>askScope();$('#dHelp').onclick=showHelp;
 $('#dExp').onchange=e=>{const v=e.target.value;e.target.value='';if(!v)return;if(v=='png')return dPng();location='/api/discovery/export?fmt='+v};
 dUI.sync=()=>{$('#dPulse').textContent='pulses: '+(DG.pulse?'on':'off');$('#dFocus').classList.toggle('on',!!DG.focus);const c=DSTATE.snap?DSTATE.snap.stats.labels:{};$('#dchips').querySelectorAll('[data-l]').forEach(b=>b.lastChild.textContent=' '+(c[b.dataset.l]||0));dRenderDock()};
 $('#dtabs').innerHTML=[['feed','live feed'],['timeline','timeline'],['assets','assets'],['sessions','history'],['env','environment']].map(([k,n])=>`<button data-t="${k}">${n}</button>`).join('')+'<span class="grow"></span><button id="dDock" title="T">▾</button>';
 $('#dtabs').onclick=e=>{if(e.target.id=='dDock'){$('#dock').classList.toggle('min');return}const t=e.target.dataset.t;if(t){DSTATE.dock=t;$('#dock').classList.remove('min');dRenderDock(true)}};
 document.addEventListener('fullscreenchange',()=>{dUI.gw.classList.toggle('fs',document.fullscreenElement===dUI.gw);setTimeout(()=>DG.rs(),60)});
 if(innerHeight<520)$('#dock').classList.add('min');
 dUI.sync();
}
async function dFullscreen(){const g=dUI.gw;try{if(document.fullscreenElement)await document.exitFullscreen();else await(g.requestFullscreen||g.webkitRequestFullscreen).call(g)}catch(e){g.classList.toggle('fs');setTimeout(()=>DG.rs(),60)}}
function dToggleFocus(){if(DG.focus)return DG.clearFocus();if(DG.sel&&DG.sel.kind)DG.focusOn(DG.sel.id);else toast('select a node first (click it), then focus')}
function dPng(){const o=document.createElement('canvas');o.width=dUI.cv.width;o.height=dUI.cv.height;const c=o.getContext('2d');c.fillStyle=TH.bg;c.fillRect(0,0,o.width,o.height);c.drawImage(dUI.cv,0,0);o.toBlob(b=>{const a=document.createElement('a');a.href=URL.createObjectURL(b);a.download='atlasflow-topology-'+new Date().toISOString().replace(/[:.]/g,'-').slice(0,19)+'.png';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),2000)})}

/* ---- run control ---- */
async function dStartStop(){const run=DSTATE.job&&DSTATE.job.state=='running';
 if(run){await post('/api/discovery/stop');return dPoll(true)}
 const sweep=$('#dSweep').checked;let body={sweep,rdns:PREF.get('rdns',true)};
 if(sweep){const env=await api('/api/discovery/env');DSTATE.env=env;let ok=env.subnets.filter(s=>s.authorized).map(s=>s.net);
  if(!ok.length){const t=env.subnets[0]?.net;if(!t){toast('no local private subnet could be determined: sweep unavailable here','warn');$('#dSweep').checked=false;return}const done=await askScope(t,true);if(!done)return;ok=[t]}
  body.targets=ok}
 const r=await post('/api/discovery/start',body);if(!r.ok)toast(r.error,'warn');DSTATE.seq=DSTATE.seq;dPoll(true)}
function askScope(target,wait){return new Promise(res=>{const m=document.createElement('div');m.className='modal on';
 api('/api/discovery/env').then(env=>{const t=target||env.subnets[0]?.net||'';m.innerHTML=`<div class="pn mbox"><h3>authorize active scope</h3><div class="mu" style="margin-bottom:8px">Active probing (TCP connect only) is locked until you attest that you own, or have written authorization to test, a target. Private/link-local space only, max /24. Every action is audit-logged.</div>
  <div class="kv"><span>target</span><input id="mT" value="${esc(t)}" style="width:100%"><span>type</span><span class="g" id="mP"></span><span></span><input id="mC" placeholder="paste/type the sentence above" style="width:100%"></div>
  <div class="am" id="mE" style="min-height:16px;margin:6px 0"></div><div class="row"><button id="mOk" class="pri">authorize</button><button id="mNo">cancel</button></div></div>`;
  const ph=()=>$('#mP').textContent='I AM AUTHORIZED TO TEST '+$('#mT').value.trim();ph();$('#mT').oninput=ph;$('#mC').focus();
  const close=v=>{m.remove();res(v)};$('#mNo').onclick=()=>close(false);
  $('#mOk').onclick=async()=>{const r=await post('/api/scope',{target:$('#mT').value.trim(),confirm:$('#mC').value});if(r.ok){toast('scope added: '+r.net);close(true)}else $('#mE').textContent=r.error};
  $('#mC').onkeydown=e=>{if(e.key=='Enter')$('#mOk').click();if(e.key=='Escape')close(false)}});document.body.appendChild(m)})}

/* ---- inspector ---- */
const CONFW={self:1,tcp:.8,'tcp-open':.9,'local-listen':.9,passive:.6,capture:.6,neighbor:.55,route:.5,rdns:.15,mdns:.5,ssdp:.5};
function dInspect(h){const el=$('#dins');DSTATE.cur=h;if(!h){el.classList.remove('on');return}el.classList.add('on');const snap=DSTATE.snap;
 const close='<button class="x" onclick="DG.sel=null;DG.hover=null;dInspect(null)">✕</button>';
 if(h.kind){const rel=DG.edges.filter(e=>e.a==h.id||e.b==h.id),nm=id=>(DG.nodes.get(id)||{}).label||id;
  const others=[...DG.nodes.values()].filter(n=>n.id!=h.id&&n.kind!='service').slice(0,150);
  el.innerHTML=`${close}<h3>${esc(h.kind)} · ${esc(h.label)}</h3><div style="margin-bottom:6px">${lb(h.l)} <span class="hl ${h.health}">${h.health||''}</span> ${(h.roles||[]).map(r=>`<span class="tag">${esc(r)}</span>`).join(' ')}</div>
  <div class="kv">${h.kind=='service'?`<span>host</span><span class="g">${esc(h.ip)}</span><span>port</span><span>${h.port}/tcp ${lb(h.l)}</span><span>service</span><span>${esc(h.service||'(unnamed)')} ${lb(h.svc_l||'UNKNOWN')}</span><span>rtt</span><span>${h.rtt!=null?h.rtt.toFixed(1)+' ms':'-'}</span>`:`<span>address</span><span class="g">${esc((h.ips||[]).join(', ')||h.id)}</span>`}
  ${(h.attrs||[]).map(a=>`<span>${esc(a.k)}</span><span>${esc(a.v)} ${lb(a.l)}<div class="mu sm">${esc(a.s||'')}${a.n?' · '+esc(a.n):''}</div></span>`).join('')}
  <span>first / last</span><span>${h.first?fAgo(h.first)+' / '+fAgo(h.last):'-'}</span></div>
  ${h.conf!=null?`<div class="h" style="margin-top:10px">confidence ${(h.conf*100).toFixed(0)}%</div><div class="cbar"><i style="width:${h.conf*100}%"></i></div><div class="mu sm">evidence: ${(h.src||[]).map(s=>esc(s)+' ('+(CONFW[s]??.3)+')').join(' · ')||'none'}<br>1 − ∏(1 − weight) over distinct sources. Measures evidence strength only.</div>`:''}
  ${(h.ports||[]).length?`<div class="h" style="margin-top:10px">open services</div>${h.ports.map(p=>`<div>${p.port}/tcp ${lb('OBSERVED')} <span class="mu">${esc(p.service||'?')}</span> ${lb(p.svc_l)}</div>`).join('')}`:''}
  ${(h.mdns||[]).length?`<div class="h" style="margin-top:10px">mDNS advertised ${lb('OBSERVED')}</div><div class="mu sm">${h.mdns.map(esc).join(' · ')}</div>`:''}
  <div class="h" style="margin-top:10px">relationships (${rel.length})</div>${rel.slice(0,40).map(e=>{const o=e.a==h.id?e.b:e.a;return`<div class="rel" data-id="${esc(o)}">${e.a==h.id?'→':'←'} <b>${esc(nm(o))}</b> <span class="mu">${esc(e.type)}</span> ${lb(e.l)}<div class="mu sm">${esc(e.info||'')}</div></div>`}).join('')||'<div class="mu">none observed</div>'}
  <div class="row" style="margin-top:10px;flex-wrap:wrap"><button id="iF">focus</button><button id="iC">copy ${h.kind=='service'?'endpoint':'address'}</button>${h.kind=='host'||h.kind=='gateway'?'<button id="iS" title="authorized scope required">scan ports</button>':''}</div>
  ${h.kind!='service'?`<div class="row" style="margin-top:6px"><select id="iP" style="flex:1"><option value="">trace path to…</option>${others.map(n=>`<option value="${esc(n.id)}">${esc(n.label)}</option>`).join('')}</select></div><div class="mu sm" style="margin-top:4px">or shift-click another node</div>`:''}
  <div id="iPath"></div>`;
  $('#iF').onclick=()=>DG.focusOn(h.id);$('#iC').onclick=()=>{const v=h.kind=='service'?h.ip+':'+h.port:h.ip;navigator.clipboard?.writeText(v).then(()=>toast('copied '+v)).catch(()=>toast(v))};
  el.querySelectorAll('.rel').forEach(r=>r.onclick=()=>{const n=DG.nodes.get(r.dataset.id);if(n){DG.sel=n;dInspect(n);DG.viewTo([h.id,n.id])}});
  const iS=$('#iS');if(iS)iS.onclick=async()=>{const t=h.ip+'/32',r=await post('/api/discovery/start',{sweep:true,targets:[t],rdns:false});if(!r.ok){if(/authorized|scope|locked/i.test(r.error||'')||true){const ok=await askScope(t);if(ok){const r2=await post('/api/discovery/start',{sweep:true,targets:[t],rdns:false});if(!r2.ok)toast(r2.error,'warn')}}}dPoll(true)};
  const iP=$('#iP');if(iP)iP.onchange=()=>{if(!iP.value)return;const r=DG.tracePath(h.id,iP.value);if(r)$('#iPath').innerHTML=`<div class="h" style="margin-top:10px">relationship path</div><div class="path">${r.ids.map((id,i)=>`<div><b>${esc(nm(id))}</b>${i<r.es.length?`<div class="mu sm">↓ ${esc(r.es[i].type)} ${lb(r.es[i].l)}</div>`:''}</div>`).join('')}</div>`}}
 else el.innerHTML=`${close}<h3>relationship · ${esc(h.type)}</h3><div>${lb(h.l)}</div><div class="kv"><span>from</span><span class="g">${esc(h.A.label)}</span><span>to</span><span class="g">${esc(h.B.label)}</span><span>weight</span><span>${h.n}</span><span>detail</span><span>${esc(h.info||'')}</span></div><div class="mu sm" style="margin-top:8px">${h.l=='OBSERVED'?'This link was read from a real table, packet or connect result.':h.l=='DETECTED'?'This link is inferred (e.g. same subnet, default route); no direct packet proves it.':'Not determinable.'}</div>`}

/* ---- polling ---- */
let dTick=0;
async function dPoll(force){if(!window.DG)return;const running=DSTATE.job&&DSTATE.job.state=='running'||(DSTATE.snap&&DSTATE.snap.listen&&DSTATE.snap.listen.running);dTick++;
 if(!force&&cur!='discovery'&&cur!='listen'&&!running&&dTick%5)return;if(document.hidden&&!force)return;
 try{const d=await api('/api/discovery?rev='+DSTATE.rev);if(!d.unchanged){DSTATE.snap=d;DSTATE.rev=d.rev;DSTATE.job=d.job;DG.ingest(d);dHud();dUI.sync()}
  const ev=await api('/api/discovery/events?since='+DSTATE.seq);if(ev.events.length){DSTATE.events.push(...ev.events);if(DSTATE.events.length>3000)DSTATE.events.splice(0,DSTATE.events.length-3000);DSTATE.seq=ev.seq;dRenderDock()}else DSTATE.seq=ev.seq;
  const b=$('#dStart');if(b){const r=DSTATE.job&&DSTATE.job.state=='running';b.textContent=r?'■ stop':'▶ start discovery';b.className=r?'dng':'pri';$('#dFsRun').textContent=r?'■':'▶'}
  const pr=$('#dProg'),j=DSTATE.job;if(pr)pr.innerHTML=j?(j.state=='running'?`<span class="scan"></span> ${j.phase}${j.total?` · ${j.done}/${j.total} probes · ${j.alive} responding · ${j.open} open`:''}`:`<span class="mu">${j.state}${j.note?' · '+esc(j.note):''} · ${fAgo(j.ended)}</span>`):'<span class="mu">idle · nothing discovered yet</span>';
  if(DSTATE.lastJobState=='running'&&j&&j.state!='running')DSTATE.sessions=null;DSTATE.lastJobState=j&&j.state}catch(e){}}
setInterval(()=>dPoll(),1000);
function dHud(){const s=DSTATE.snap;if(!s)return;const k=s.stats.kinds;$('#dhud').innerHTML=`<span>assets <b>${(k.host||0)+(k.self||0)+(k.gateway||0)}</b></span><span>services <b>${k.service||0}</b></span><span>links <b>${s.stats.edges}</b></span>${s.listen&&s.listen.running?'<span class="g"><i class="dot on"></i>listening</span>':''}${DSTATE.job&&DSTATE.job.state=='running'?'<span class="g"><i class="dot on"></i>scanning</span>':''}`;
 const e=$('#dEmpty'),none=!s.nodes.length;e.classList.toggle('on',none);if(none)e.innerHTML=`<img src="/static/logo_atlas_green.png" alt=""><b>[ NOTHING DISCOVERED YET ]</b><div class="mu" style="max-width:520px">Start discovery to read this host's network environment (interfaces, gateway, DNS, neighbor cache). Enable <i>authorized sweep</i> to actively probe a subnet you are authorized to test, or use LISTEN for passive observation. Nothing is simulated.</div>`}

/* ---- dock ---- */
function dRenderDock(force){const body=$('#dbody');if(!body)return;document.querySelectorAll('#dtabs [data-t]').forEach(b=>b.classList.toggle('on',b.dataset.t==DSTATE.dock));if($('#dock').classList.contains('min')&&!force)return;
 ({feed:dFeed,timeline:dTimeline,assets:dAssets,sessions:dSessions,env:dEnv})[DSTATE.dock](body,force)}
function dFeed(b){let box=b.querySelector('.feed');if(!box){b.innerHTML='<div class="feed"></div>';box=b.firstChild;box._n=0}const stick=box.scrollTop+box.clientHeight>=box.scrollHeight-30,ev=DSTATE.events;
 if(box._n>ev.length||box._first!==(ev[0]||{}).seq){box.innerHTML='';box._n=0}box._first=(ev[0]||{}).seq;
 const add=ev.slice(box._n).map(e=>`<div class="ev2" ${e.ref?`data-r="${esc(e.ref)}"`:''}><span class="mu">${new Date(e.t*1000).toISOString().slice(11,23)}</span><span class="k k-${e.k}">${e.k}</span>${e.l?lb(e.l):'<span></span>'}<span>${esc(e.msg)}</span></div>`).join('');box._n=ev.length;box.insertAdjacentHTML('beforeend',add);if(stick)box.scrollTop=box.scrollHeight;
 box.onclick=e=>{const r=e.target.closest('[data-r]');if(!r)return;const n=DG.nodes.get(r.dataset.r);if(n){DG.sel=n;dInspect(n);DG.viewTo([n.id])}}}
function dTimeline(b){b.innerHTML='<div class="tlw"><canvas id="dtl"></canvas></div>';const w=b.firstChild,cv=w.firstChild,ev=DSTATE.events.filter(e=>e.ref||['PHASE','SCAN','SESSION'].includes(e.k));if(!ev.length){w.innerHTML='<div class="mu" style="padding:10px">no events yet</div>';return}
 const rows=[],idx=new Map();ev.forEach(e=>{if(e.k=='ASSET'&&!idx.has(e.ref)){idx.set(e.ref,rows.length);rows.push({id:e.ref,t:e.t,m:[]})}});ev.forEach(e=>{if((e.k=='PORT'||e.k=='NAME'||e.k=='MAC')&&idx.has(e.ref))rows[idx.get(e.ref)].m.push(e)});
 const t0=ev[0].t,t1=Math.max(Date.now()/1000,ev[ev.length-1].t),W=w.clientWidth||600,L=150,RH=15,Hh=Math.max(w.clientHeight||120,rows.length*RH+34),d=devicePixelRatio||1;cv.style.width=W+'px';cv.style.height=Hh+'px';cv.width=W*d;cv.height=Hh*d;const c=cv.getContext('2d');c.scale(d,d);
 const X=t=>L+(t-t0)/Math.max(1,t1-t0)*(W-L-16);c.font='10px '+DG.fam;
 ev.filter(e=>['PHASE','SCAN','SESSION'].includes(e.k)).forEach(e=>{const x=X(e.t);c.strokeStyle='rgba(123,142,132,.35)';c.beginPath();c.moveTo(x,14);c.lineTo(x,Hh);c.stroke()});
 c.fillStyle=TH.mu;c.fillText('+0s',L,10);const te='+'+(t1-t0).toFixed(1)+'s';c.fillText(te,W-c.measureText(te).width-8,10);
 rows.forEach((r,i)=>{const y=26+i*RH,n=DG.nodes.get(r.id);c.fillStyle=TH.fg;c.fillText(((n&&n.label)||r.id).slice(0,22),6,y+3);c.strokeStyle='rgba(63,182,122,.35)';c.lineWidth=2;c.beginPath();c.moveTo(X(r.t),y);c.lineTo(X(t1),y);c.stroke();c.lineWidth=1;c.fillStyle=TH.g;c.beginPath();c.arc(X(r.t),y,3.5,0,6.3);c.fill();
  r.m.forEach(m=>{c.fillStyle=m.k=='PORT'?TH.g2:TH.am;c.fillRect(X(m.t)-2,y-2,4,4)})});
 c.fillStyle=TH.mu;c.fillText('● first observed   ■ port / name / MAC learned   │ phase boundary',L,Hh-4)}
function dAssets(b){const s=DSTATE.snap;if(!s){b.innerHTML='<div class="mu" style="padding:10px">no data</div>';return}
 let rows=s.nodes.filter(n=>n.kind!='service'&&DG.vis(n)&&(!DG.F.q||(DG.nodes.get(n.id)||{_t:''})._t.includes(DG.F.q)));const so=DSTATE.sort||['kind',1];
 const key={kind:n=>TIER[n.kind],label:n=>n.label.toLowerCase(),l:n=>n.l,conf:n=>n.conf||0,health:n=>n.health||'',mac:n=>n.mac||'',vendor:n=>n.vendor||'',ports:n=>n.ports.length,last:n=>n.last||0}[so[0]];rows.sort((a,b)=>{const x=key(a),y=key(b);return(x>y?1:x<y?-1:0)*so[1]});
 const C=[['label','asset'],['kind','kind'],['l','provenance'],['conf','confidence'],['health','health'],['mac','MAC'],['vendor','vendor'],['ports','ports'],['last','last seen']];
 b.innerHTML=`<div class="tw"><table><thead><tr>${C.map(c=>`<th data-s="${c[0]}">${c[1]}${so[0]==c[0]?so[1]>0?' ▲':' ▼':''}</th>`).join('')}</tr></thead><tbody>${rows.map(n=>`<tr data-id="${esc(n.id)}"><td class="g">${esc(n.label)}${n.label!=n.id?` <span class="mu">${esc(n.id)}</span>`:''}</td><td>${n.kind}${(n.roles||[]).length?` <span class="mu">${n.roles.join(',')}</span>`:''}</td><td>${lb(n.l)}</td><td><span class="cbar sm"><i style="width:${(n.conf||0)*100}%"></i></span> ${((n.conf||0)*100).toFixed(0)}%</td><td><span class="hl ${n.health}">${n.health||''}</span></td><td>${esc(n.mac||'UNKNOWN')}</td><td>${esc(n.vendor||'UNKNOWN')}</td><td>${n.ports.map(p=>p.port).join(' ')}</td><td class="mu">${fAgo(n.last)}</td></tr>`).join('')||'<tr><td class="mu" colspan="9">no matching assets</td></tr>'}</tbody></table></div>`;
 b.querySelector('thead').onclick=e=>{const k=e.target.dataset.s;if(!k)return;DSTATE.sort=[k,so[0]==k?-so[1]:1];dAssets(b)};b.querySelector('tbody').onclick=e=>{const r=e.target.closest('tr');if(!r||!r.dataset.id)return;const n=DG.nodes.get(r.dataset.id);if(n){DG.sel=n;dInspect(n);DG.viewTo([n.id])}}}
async function dSessions(b,force){if(!DSTATE.sessions||force){const d=await api('/api/discovery/sessions');DSTATE.sessions=d}const d=DSTATE.sessions,T=t=>new Date(t*1000).toISOString().slice(0,19).replace('T',' ');
 b.innerHTML=`<div class="row" style="padding:4px 6px"><span class="mu">stored in ${esc(d.home||'(memory only: data dir not writable)')} · summaries + topology snapshots, never packet payloads</span><span class="grow"></span><button id="sRef">refresh</button><button id="sClr" class="dng">clear history</button></div><div class="tw"><table><thead><tr><th>session</th><th>type</th><th>state</th><th>started</th><th>duration</th><th>mode</th><th>result</th><th></th></tr></thead><tbody>${d.sessions.map(s=>`<tr><td class="g">${s.id}</td><td>${s.type}</td><td>${s.state}</td><td>${T(s.started)}</td><td>${(s.ended-s.started).toFixed(1)}s</td><td class="mu">${s.type=='discovery'?(s.opts&&s.opts.sweep?'authorized sweep':'local observation'):'passive listen'}</td><td>${Object.entries(s.summary||{}).map(x=>x.join(' ')).join(' · ')}</td><td>${d.home?`<a href="/api/discovery/session?id=${s.id}" class="g">json</a>`:''}</td></tr>`).join('')||'<tr><td class="mu" colspan="8">no sessions recorded yet</td></tr>'}</tbody></table></div>`;
 $('#sRef').onclick=()=>dSessions(b,true);$('#sClr').onclick=async()=>{if(confirm('Delete all stored session history?')){await post('/api/discovery/clear-history');DSTATE.sessions=null;dSessions(b,true)}}}
async function dEnv(b,force){if(!DSTATE.env||force)DSTATE.env=await api('/api/discovery/env');const e=DSTATE.env,caps=await api('/api/listen/caps'),P=e.platform;
 b.innerHTML=`<div class="envg"><div><div class="h">platform ${lb('OBSERVED')}</div><div class="kv"><span>system</span><span>${esc(P.system)} ${esc(P.release)} ${esc(P.machine)}</span><span>android</span><span>${P.android?'yes'+(P.termux?' (Termux)':''):'no'}</span><span>python</span><span>${esc(P.python)}</span><span>privilege</span><span>${P.root?'root':'unprivileged'}</span></div>
 <div class="h" style="margin-top:8px">gateway ${lb(e.gateway?'OBSERVED':'UNKNOWN')}</div><div>${e.gateway?`<span class="g">${esc(e.gateway.ip)}</span> via ${esc(e.gateway.iface||'?')} <span class="mu">(${esc(e.gateway.src)})</span>`:'<span class="mu">no default route readable</span>'}</div>
 <div class="h" style="margin-top:8px">dns ${lb(e.dns.servers.length?'OBSERVED':'UNKNOWN')}</div><div>${e.dns.servers.map(d=>`<span class="g">${esc(d.ip)}</span>${d.stub?' <span class="mu">(local stub)</span>':''}`).join(', ')||'<span class="mu">none readable</span>'}${e.dns.search.length?`<div class="mu sm">search: ${esc(e.dns.search.join(' '))}</div>`:''}</div></div>
 <div><div class="h">interfaces ${lb(e.iface_src?'OBSERVED':'UNKNOWN')} <span class="mu sm">${esc(e.iface_src||'')}</span></div><div class="tw"><table><tbody>${e.interfaces.map(i=>`<tr><td class="g">${esc(i.name)}</td><td>${i.kind}</td><td class="mu">${esc(i.state)}</td><td>${esc(i.mac||'UNKNOWN')}</td><td>${i.addrs.map(a=>esc(a.ip)+(a.prefix?'/'+a.prefix:'')).join(' ')||'<span class="mu">no address readable</span>'}</td></tr>`).join('')}</tbody></table></div>
 <div class="h" style="margin-top:8px">sweepable subnets</div>${e.subnets.map(s=>`<div><span class="g">${esc(s.net)}</span> on ${esc(s.iface)} ${s.prefix_known?'':'<span class="mu">(netmask unknown: /24 assumed)</span>'} ${s.clamped?'<span class="mu">(clamped to /24)</span>':''} ${s.authorized?'<span class="lb OBSERVED">AUTHORIZED</span>':`<button data-a="${esc(s.net)}">authorize…</button>`}</div>`).join('')||'<div class="mu">none (no private IPv4 subnet determinable)</div>'}</div>
 <div><div class="h">listen capabilities</div>${Object.entries(caps).map(([k,v])=>`<div><i class="dot ${v.ok?'on':''}"></i> <b>${k}</b> <span class="mu sm">${esc(v.why)}</span></div>`).join('')}<div class="h" style="margin-top:8px">neighbor cache ${lb(e.neighbor_readable?'OBSERVED':'UNKNOWN')}</div><div class="mu sm">${e.neighbor_readable?esc(e.neighbor_src.join(', ')):'not readable here (common on Android without root); LAN peers come from sweep or LISTEN'}</div></div></div>`;
 b.querySelectorAll('[data-a]').forEach(x=>x.onclick=async()=>{if(await askScope(x.dataset.a)){DSTATE.env=null;dEnv(b,true)}})}

/* ================= LISTEN view ================= */
const LSTATE={d:null};
function buildListen(){const sec=document.createElement('section');sec.className='v';sec.id='v-listen';
 sec.innerHTML=`<div class="dwrap lw"><div class="dbar"><button id="lStart" class="pri" title="L">▶ start listening</button><select id="lIf" title="interface (raw capture only)"><option value="any">all interfaces</option></select><span id="lSt" class="dprog"></span><span class="grow"></span><span class="mu sm" id="lPriv"></span></div>
 <div class="lgrid"><div class="col"><div class="lcards" id="lCards"></div><div class="pn"><h3>events / second</h3><div style="height:70px"><canvas id="lSp"></canvas></div></div><div class="pn scroll fill"><h3>interface activity</h3><div id="lIfs"></div></div><div class="pn"><h3>protocols</h3><div id="lPr" class="bars" style="grid-template-columns:80px 1fr 60px"></div></div></div>
 <div class="col"><div class="pn scroll fill"><h3>observed hosts</h3><div id="lHosts"></div></div><div class="pn scroll" style="height:38%"><h3>sources</h3><div id="lSrc"></div></div></div>
 <div class="col"><div class="pn scroll fill"><h3>observed connections</h3><div id="lConns"></div></div><div class="pn scroll" style="height:38%"><h3>event feed (sampled metadata)</h3><div id="lFeed" class="feed"></div></div></div></div></div>`;
 $('main').appendChild(sec);$('#lStart').onclick=lStartStop;
 api('/api/ifaces').then(l=>{$('#lIf').innerHTML+=l.filter(i=>i.name).map(i=>`<option value="${esc(i.name)}">${esc(i.name)} · ${i.kind}</option>`).join('')})}
async function lStartStop(){const run=LSTATE.d&&LSTATE.d.brief.running;const r=await post(run?'/api/listen/stop':'/api/listen/start',{iface:$('#lIf').value});if(!r.ok)toast(r.error,'warn');DSTATE.sessions=null;lPoll(true);dPoll(true)}
async function lPoll(force){if(!$('#lStart'))return;const run=LSTATE.d&&LSTATE.d.brief.running;if(!force&&cur!='listen'&&!run)return;try{LSTATE.d=await api('/api/listen');if(cur=='listen')rListen()}catch(e){}}
setInterval(()=>lPoll(),1000);
function rListen(){const d=LSTATE.d;if(!d)return lPoll(true);const b=d.brief,run=b.running,tl=d.timeline,now=Math.floor(Date.now()/1000);
 $('#lStart').textContent=run?'■ stop listening':'▶ start listening';$('#lStart').className=run?'dng':'pri';$('#lIf').disabled=run;
 $('#lSt').innerHTML=run?`<span class="scan"></span> listening since ${fAgo(b.started)}`:b.sid?`<span class="mu">stopped · ${b.events} events observed</span>`:'<span class="mu">not listening: press start (explicit consent required each time)</span>';$('#lPriv').textContent=d.privacy;
 const rate=tl.length?(tl.filter(x=>x[0]>=now-3).reduce((a,x)=>a+x[1],0)/3):0,fb=n=>n<1024?n+' B':n<1048576?(n/1024).toFixed(1)+' KB':(n/1048576).toFixed(1)+' MB';
 $('#lCards').innerHTML=[['events',b.events],['per sec',rate.toFixed(1)],['hosts',b.hosts],['conns',b.conns],['bytes',fb(b.bytes)]].map(([k,v])=>`<div class="card"><b>${v}</b><span>${k}</span></div>`).join('');
 const sp=$('#lSp'),w=sp.parentElement,W=w.clientWidth||300,H=70,dp=devicePixelRatio||1;sp.width=W*dp;sp.height=H*dp;sp.style.width=W+'px';const c=sp.getContext('2d');c.scale(dp,dp);const m=Math.max(1,...tl.map(x=>x[1])),n=Math.min(120,Math.max(30,W/4)|0);
 for(let i=0;i<n;i++){const t=now-n+1+i,v=(tl.find(x=>x[0]==t)||[0,0])[1],h=v/m*(H-14);c.fillStyle=TH.g;c.globalAlpha=.85;c.fillRect(i*(W/n),H-h,Math.max(1,W/n-1),h)}c.globalAlpha=1;c.fillStyle=TH.mu;c.font='10px '+DG.fam;c.fillText('peak '+m+'/s',4,10);
 $('#lIfs').innerHTML=d.ifaces.length?d.ifaces.map(i=>{const mx=Math.max(1,...i.hist);return`<div class="ifr"><b class="g">${esc(i.name)}</b> <span class="mu">${i.kind}</span><span class="grow"></span><span>↓ ${fRate(i.rx_rate)}</span><span>↑ ${fRate(i.tx_rate)}</span><div class="spark">${i.hist.map(v=>`<i style="height:${Math.max(1,v/mx*100)}%"></i>`).join('')}</div><div class="mu sm">since start: ${i.rx_p} rx / ${i.tx_p} tx pkts · ${fb(i.rx_b)} / ${fb(i.tx_b)}${i.drops?' · drops '+i.drops:''}${i.errs?' · errors '+i.errs:''}</div></div>`}).join(''):`<div class="mu">${run?'waiting for first counter sample…':(d.sources.netdev&&d.sources.netdev.state=='unavailable')?'UNKNOWN: interface counters unreadable here':'start listening to read interface counters'}</div>`;
 const pm=Math.max(1,...d.protocols.map(p=>p[1]));$('#lPr').innerHTML=d.protocols.map(p=>`<span>${esc(p[0])}</span><div class="bar" style="width:${100*p[1]/pm}%"></div><span>${p[1]}</span>`).join('')||'<span class="mu">none observed</span>';
 $('#lHosts').innerHTML=`<div class="tw"><table><thead><tr><th>host</th><th>scope</th><th>pkts</th><th>out / in</th><th>protocols</th><th>MAC</th><th>last</th></tr></thead><tbody>${d.hosts.map(h=>`<tr><td class="g">${esc(h.ip)}</td><td class="${h.scope=='local'?'':'mu'}">${h.scope}</td><td class="num">${h.pk}</td><td>${fB(h.out)} / ${fB(h.inn)}</td><td class="mu">${h.protos.map(p=>p[0]).join(' ')}</td><td>${esc(h.macs.join(' ')||'UNKNOWN')}</td><td class="mu">${fAgo(h.last)}</td></tr>`).join('')||'<tr><td class="mu" colspan="7">no hosts observed yet</td></tr>'}</tbody></table></div>`;
 $('#lConns').innerHTML=`<div class="tw"><table><thead><tr><th>src</th><th>dst</th><th>proto</th><th>port</th><th>events</th><th>last</th><th>via</th></tr></thead><tbody>${d.conns.map(c=>`<tr><td>${esc(c.src)}</td><td>${esc(c.dst)}</td><td class="g">${esc(c.proto)}</td><td>${c.dp||''}</td><td class="num">${c.n}</td><td class="mu">${fAgo(c.last)}</td><td class="mu">${c.via.join(',')}</td></tr>`).join('')||'<tr><td class="mu" colspan="7">no connections observed yet</td></tr>'}</tbody></table></div>`;
 $('#lSrc').innerHTML=Object.entries(d.sources).map(([k,v])=>`<div><i class="dot ${v.state=='active'?'on':''}"></i> <b>${k}</b> <span class="${v.state=='unavailable'?'am':'mu'}">${v.state}</span><div class="mu sm">${esc(v.why)}</div></div>`).join('')||'<div class="mu">start listening to see which passive sources this platform allows</div>';
 const f=$('#lFeed');f.innerHTML=d.feed.slice().reverse().map(e=>`<div class="ev3"><span class="mu">${new Date(e.t*1000).toISOString().slice(11,23)}</span><span class="g">${esc(e.proto)}</span><span>${esc(e.src)}${e.sp?':'+e.sp:''} → ${esc(e.dst)}${e.dp?':'+e.dp:''}</span><span class="mu">${e.len}B</span></div>`).join('')||'<div class="mu">no events</div>'}

/* ================= settings extras, footer, shortcuts, help ================= */
window.footExtra=()=>{const d=S.disc;if(!d)return'';return`<span>assets <b>${d.assets}</b></span>${d.running?'<span class="g"><i class="dot on"></i>scanning</span>':''}${d.listen?'<span class="g"><i class="dot on"></i>listening</span>':''}`};
window.setExtra=()=>{const P=S.plat||{};return`<div class="pn"><h3>cybernyx · interface</h3><div class="row" style="flex-wrap:wrap;gap:14px"><label><input type="checkbox" id="x1" ${PREF.get('mute',false)?'':'checked'}> boot &amp; interface sounds</label><label>boot sequence <select id="x2"><option value="session">once per session</option><option value="always">every load</option><option value="off">off</option></select></label><label><input type="checkbox" id="x3" ${PREF.get('fx',true)?'checked':''}> animations (graph pulses, radar, glitch)</label><label><input type="checkbox" id="x4" ${PREF.get('rdns',true)?'checked':''}> reverse-DNS lookups during discovery</label><button id="x5">replay boot</button></div>
 <div class="kv" style="margin-top:10px"><span>version</span><span>${esc(S.version||'')}</span><span>platform</span><span>${esc(P.system||'?')} ${P.android?'· Android':''} ${P.termux?'· Termux':''} · python ${esc(P.python||'?')} · ${P.root?'root':'unprivileged'}</span><span>orientation</span><span>${(P.android||/Android/i.test(navigator.userAgent))?'Android: GUI requests landscape+fullscreen on start ('+(screen.orientation?screen.orientation.type:'n/a')+') <button id="x6">retry landscape</button>':'desktop: n/a'}</span></div></div>`};
window.setExtraBind=el=>{const g=id=>el.querySelector(id);g('#x2').value=PREF.get('boot','session');g('#x1').onchange=e=>{PREF.set('mute',!e.target.checked);if(e.target.checked&&window.SND)SND.blip(880,.06)};g('#x2').onchange=e=>PREF.set('boot',e.target.value);
 g('#x3').onchange=e=>{PREF.set('fx',e.target.checked);document.body.classList.toggle('nofx',!e.target.checked)};g('#x4').onchange=e=>PREF.set('rdns',e.target.checked);g('#x5').onclick=()=>{sessionStorage.removeItem('atlas.booted');window.Boot&&Boot.run(true)};const r=g('#x6');if(r)r.onclick=()=>window.Android&&Android.land(true)};
const KEYS=[['1 … 9','jump to view'],['[ ]','previous / next view'],['S','start / stop discovery'],['L','start / stop listening'],['/','search assets'],['F','fullscreen graph'],['R','fit graph (Shift+R: re-layout)'],['X','focus / unfocus selected node'],['P','toggle packet pulses'],['T','toggle bottom dock'],['I','toggle inspector'],['E','export full JSON'],['Shift+click','trace path between two nodes'],['Double-click','focus a node'],['M','mute / unmute sounds'],['B','replay boot sequence'],['Esc','clear selection / focus / close'],['?','this help']];
function showHelp(){let m=$('#help');if(m){m.remove();return}m=document.createElement('div');m.id='help';m.className='modal on';m.innerHTML=`<div class="pn mbox"><h3>keyboard shortcuts</h3><div class="kv" style="grid-template-columns:110px 1fr">${KEYS.map(k=>`<span class="g">${k[0]}</span><span>${k[1]}</span>`).join('')}</div><div class="row" style="margin-top:10px"><button id="hx" class="pri">close</button></div></div>`;m.onclick=e=>{if(e.target==m||e.target.id=='hx')m.remove()};document.body.appendChild(m)}
document.addEventListener('keydown',e=>{const t=e.target,typing=t&&(/INPUT|TEXTAREA|SELECT/.test(t.tagName));if(e.key=='Escape'){document.querySelectorAll('.modal').forEach(m=>m.remove());if(typing){t.blur();return}if(window.DG){if(DG.focus||DG.path)DG.clearFocus();else if(DG.sel){DG.sel=null;dInspect(null)}}return}
 if(typing||e.ctrlKey||e.metaKey||e.altKey||(window.Boot&&Boot.active))return;const k=e.key,K=k.toLowerCase();
 if(/^[1-9]$/.test(k)&&VIEWS[+k-1])return go(VIEWS[+k-1]);if(k==']'||k=='['){const i=VIEWS.indexOf(cur);return go(VIEWS[(i+(k==']'?1:-1)+VIEWS.length)%VIEWS.length])}
 if(k=='?')return showHelp();if(K=='m'){PREF.set('mute',!PREF.get('mute',false));toast('sounds '+(PREF.get('mute',false)?'muted':'on'));return}if(K=='b'){sessionStorage.removeItem('atlas.booted');return window.Boot&&Boot.run(true)}
 if(K=='s'&&cur=='discovery')return dStartStop();if(K=='l'&&(cur=='listen'||cur=='discovery'))return lStartStop();
 if(cur=='discovery'&&window.DG){if(k=='/'){e.preventDefault();return $('#dq').focus()}if(k=='R'){return DG.relayout()}if(K=='r'){DG.userMoved=false;return DG.fitView()}if(K=='f')return dFullscreen();if(K=='x')return dToggleFocus();
  if(K=='p'){DG.pulse=!DG.pulse;if(!DG.pulse)DG.pulses=[];return dUI.sync()}if(K=='t'){$('#dock').classList.toggle('min');return dRenderDock(true)}if(K=='i'){$('#dins').classList.toggle('on');return}if(K=='e')return(location='/api/discovery/export?fmt=json')}});

/* ---- wire into the existing app ---- */
buildDiscovery();buildListen();VIEWMAP.discovery=()=>{DG.rs();dPoll(true);dRenderDock(true)};VIEWMAP.listen=()=>rListen();
